// Test script for MySociety Manager API
const fetch = require('node-fetch');

async function testAPI() {
    console.log('Testing MySociety Manager API...\n');
    
    // Test society registration
    console.log('1. Testing society registration...');
    try {
        const registrationResponse = await fetch('http://localhost:3000/api/societies/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                societyName: 'Test Society',
                address: '123 Test St',
                city: 'Test City',
                numberOfFlats: 10,
                presidentName: 'Test President',
                presidentEmail: 'test@example.com',
                presidentMobile: '1234567890',
                password: 'testpass123'
            }),
        });
        
        const registrationData = await registrationResponse.json();
        console.log('Registration response:', registrationData);
    } catch (error) {
        console.error('Registration error:', error);
    }
    
    // Test president login
    console.log('\n2. Testing president login...');
    try {
        const loginResponse = await fetch('http://localhost:3000/api/auth/president/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email: 'test@example.com',
                password: 'testpass123'
            }),
        });
        
        const loginData = await loginResponse.json();
        console.log('Login response:', loginData);
    } catch (error) {
        console.error('Login error:', error);
    }
    
    // Test treasurer login
    console.log('\n3. Testing treasurer login...');
    try {
        const loginResponse = await fetch('http://localhost:3000/api/auth/treasurer/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email: 'test@example.com',
                password: 'testpass123'
            }),
        });
        
        const loginData = await loginResponse.json();
        console.log('Login response:', loginData);
    } catch (error) {
        console.error('Login error:', error);
    }
    
    // Test resident login
    console.log('\n4. Testing resident login...');
    try {
        const loginResponse = await fetch('http://localhost:3000/api/auth/resident/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email: 'test@example.com',
                password: 'testpass123'
            }),
        });
        
        const loginData = await loginResponse.json();
        console.log('Login response:', loginData);
    } catch (error) {
        console.error('Login error:', error);
    }
    
    // Test getting society data
    console.log('\n5. Testing get society data...');
    try {
        const societyResponse = await fetch('http://localhost:3000/api/societies/123');
        const societyData = await societyResponse.json();
        console.log('Society data:', societyData);
    } catch (error) {
        console.error('Society data error:', error);
    }
    
    // Test getting residents data
    console.log('\n6. Testing get residents data...');
    try {
        const residentsResponse = await fetch('http://localhost:3000/api/societies/123/residents');
        const residentsData = await residentsResponse.json();
        console.log('Residents data:', residentsData);
    } catch (error) {
        console.error('Residents data error:', error);
    }
    
    console.log('\nAPI testing completed.');
}

// Run the test
testAPI();