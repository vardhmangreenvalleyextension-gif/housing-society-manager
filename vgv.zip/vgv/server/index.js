const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

// Import database functions
const {
    createSociety,
    getAllSocieties,
    getSocietyById,
    updateSociety,
    deleteSociety,
    createUser,
    getUserByEmail,
    getAllUsers,
    createResident,
    getResidentById,
    updateResident,
    deleteResident,
    getResidentsBySocietyId,
    searchSocieties
} = require('../database');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// CORS middleware
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    
    if (req.method === 'OPTIONS') {
        res.sendStatus(200);
    } else {
        next();
    }
});

// Log all requests for debugging
app.use((req, res, next) => {
    console.log(`${req.method} ${req.path}`);
    next();
});

// API routes first (before static files)
// Register a new society
app.post('/api/societies/register', (req, res) => {
  try {
    console.log('Register society request received');
    const { societyName, address, city, numberOfFlats, presidentName, presidentEmail, presidentMobile, password } = req.body;
    
    // Basic validation
    if (!societyName || !address || !city || !numberOfFlats || !presidentName || !presidentEmail || !presidentMobile || !password) {
      return res.status(400).json({ 
        success: false, 
        message: 'All fields are required' 
      });
    }
    
    // Create society in database
    const newSociety = createSociety({
      societyName,
      address,
      city,
      numberOfFlats: parseInt(numberOfFlats),
      presidentName,
      presidentEmail,
      presidentMobile
    });
    
    if (!newSociety) {
      return res.status(500).json({ 
        success: false, 
        message: 'Failed to create society' 
      });
    }
    
    // Create user for president
    const newUser = createUser({
      name: presidentName,
      email: presidentEmail,
      role: 'president',
      societyId: newSociety.id
    });
    
    // Send success response
    res.status(201).json({ 
      success: true, 
      message: 'Society registered successfully!',
      society: newSociety,
      user: newUser
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});

// President login
app.post('/api/auth/president/login', (req, res) => {
  try {
    console.log('President login request received');
    const { email, password } = req.body;
    
    // Basic validation
    if (!email || !password) {
      return res.status(400).json({ 
        success: false, 
        message: 'Email and password are required' 
      });
    }
    
    // In a real application, you would:
    // 1. Validate credentials against database
    // 2. Generate JWT token
    
    // For this demo, we'll simulate a successful login
    const user = {
      id: 1,
      name: "John Smith",
      email: email,
      role: "president"
    };
    
    res.json({ 
      success: true, 
      message: 'Login successful',
      user: user,
      token: "sample-jwt-token"
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});

// Treasurer login
app.post('/api/auth/treasurer/login', (req, res) => {
  try {
    console.log('Treasurer login request received');
    const { email, password } = req.body;
    
    // Basic validation
    if (!email || !password) {
      return res.status(400).json({ 
        success: false, 
        message: 'Email and password are required' 
      });
    }
    
    // In a real application, you would:
    // 1. Validate credentials against database
    // 2. Generate JWT token
    
    // For this demo, we'll simulate a successful login
    const user = {
      id: 2,
      name: "Jane Treasurer",
      email: email,
      role: "treasurer"
    };
    
    res.json({ 
      success: true, 
      message: 'Login successful',
      user: user,
      token: "sample-jwt-token"
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});

// Resident login
app.post('/api/auth/resident/login', (req, res) => {
  try {
    console.log('Resident login request received');
    const { email, password } = req.body;
    
    // Basic validation
    if (!email || !password) {
      return res.status(400).json({ 
        success: false, 
        message: 'Email and password are required' 
      });
    }
    
    // In a real application, you would:
    // 1. Validate credentials against database
    // 2. Generate JWT token
    
    // For this demo, we'll simulate a successful login
    const user = {
      id: 3,
      name: "Sarah Johnson",
      email: email,
      role: "resident",
      flat: "A-102"
    };
    
    res.json({ 
      success: true, 
      message: 'Login successful',
      user: user,
      token: "sample-jwt-token"
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});

// Get society data
app.get('/api/societies/:id', (req, res) => {
  try {
    console.log('Get society request received');
    const { id } = req.params;
    
    const society = getSocietyById(id);
    
    if (!society) {
      return res.status(404).json({ 
        success: false, 
        message: 'Society not found' 
      });
    }
    
    res.json({ 
      success: true, 
      society: society 
    });
  } catch (error) {
    console.error('Error fetching society:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});

// Get all societies (for admin dashboard)
app.get('/api/societies', (req, res) => {
  try {
    console.log('Get all societies request received');
    const societies = getAllSocieties();
    
    res.json({ 
      success: true, 
      societies: societies,
      totalCount: societies.length
    });
  } catch (error) {
    console.error('Error fetching societies:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});

// Search and filter societies
app.get('/api/societies/search', (req, res) => {
  try {
    console.log('Search societies request received');
    const { search, filter, page, limit } = req.query;
    
    const societies = searchSocieties(search, filter);
    
    // Apply pagination
    const pageNum = parseInt(page) || 1;
    const pageSize = parseInt(limit) || 10;
    const startIndex = (pageNum - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    const paginatedSocieties = societies.slice(startIndex, endIndex);
    
    res.json({ 
      success: true, 
      societies: paginatedSocieties,
      totalCount: societies.length,
      currentPage: pageNum,
      totalPages: Math.ceil(societies.length / pageSize)
    });
  } catch (error) {
    console.error('Error searching societies:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});

// Get residents data
app.get('/api/societies/:id/residents', (req, res) => {
  try {
    console.log('Get residents request received');
    const { id } = req.params;
    
    const residents = getResidentsBySocietyId(id);
    
    res.json({ 
      success: true, 
      residents: residents 
    });
  } catch (error) {
    console.error('Error fetching residents:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});

// Create resident
app.post('/api/societies/:id/residents', (req, res) => {
  try {
    console.log('Create resident request received');
    const { id } = req.params;
    const residentData = req.body;
    
    // Add society ID to resident data
    residentData.societyId = id;
    
    const newResident = createResident(residentData);
    
    if (!newResident) {
      return res.status(500).json({ 
        success: false, 
        message: 'Failed to create resident' 
      });
    }
    
    res.status(201).json({ 
      success: true, 
      message: 'Resident created successfully!',
      resident: newResident
    });
  } catch (error) {
    console.error('Error creating resident:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});

// Update resident
app.put('/api/residents/:id', (req, res) => {
  try {
    console.log('Update resident request received');
    const { id } = req.params;
    const updateData = req.body;
    
    const success = updateResident(id, updateData);
    
    if (!success) {
      return res.status(404).json({ 
        success: false, 
        message: 'Resident not found' 
      });
    }
    
    const updatedResident = getResidentById(id);
    
    res.json({ 
      success: true, 
      message: 'Resident updated successfully!',
      resident: updatedResident
    });
  } catch (error) {
    console.error('Error updating resident:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});

// Delete resident
app.delete('/api/residents/:id', (req, res) => {
  try {
    console.log('Delete resident request received');
    const { id } = req.params;
    
    const success = deleteResident(id);
    
    if (!success) {
      return res.status(404).json({ 
        success: false, 
        message: 'Resident not found' 
      });
    }
    
    res.json({ 
      success: true, 
      message: 'Resident deleted successfully!'
    });
  } catch (error) {
    console.error('Error deleting resident:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});

// Serve static files from the root directory (after API routes)
app.use(express.static(path.join(__dirname, '..')));

// Serve index.html for the root route and other specific routes
app.get('/', (req, res) => {
  console.log('Serving index.html');
  res.sendFile(path.join(__dirname, '../index.html'));
});

app.get('/admin.html', (req, res) => {
  console.log('Serving admin.html');
  res.sendFile(path.join(__dirname, '../admin.html'));
});

app.get('/admin-login.html', (req, res) => {
  console.log('Serving admin-login.html');
  res.sendFile(path.join(__dirname, '../admin-login.html'));
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
  console.log(`API endpoints:`);
  console.log(`  POST /api/societies/register`);
  console.log(`  POST /api/auth/president/login`);
  console.log(`  POST /api/auth/treasurer/login`);
  console.log(`  POST /api/auth/resident/login`);
  console.log(`  GET /api/societies/:id`);
  console.log(`  GET /api/societies`);
  console.log(`  GET /api/societies/search`);
  console.log(`  GET /api/societies/:id/residents`);
});