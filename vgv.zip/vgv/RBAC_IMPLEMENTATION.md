# Role-Based Access Control (RBAC) Implementation

## Overview

This document describes the implementation of Role-Based Access Control (RBAC) in the MySociety Manager platform. The system defines three distinct user roles with specific permissions tailored to their responsibilities within a housing society.

## User Roles

### 1. President
**Role**: Owner/manager of a housing society
**Access Level**: Full administrative access

#### Permissions
- ✅ View and edit society-level settings
- ✅ Configure monthly service charges (maintenance, parking, water, light, other)
- ✅ Add/edit/remove residents and their flats
- ✅ Define and manage roles for Treasurer
- ✅ View complete financial overview (total collections, total expenses, current balance)
- ✅ View all residents' balances and dues
- ✅ Create and manage meetings (create, update, cancel; add minutes/notes)
- ✅ Manage global announcements for all residents
- ✅ View complaints overview (see all complaints from all residents)
- ✅ Change complaint status (Open/In Progress/Resolved)
- ✅ Approve expense entries added by Treasurer
- ✅ Access reports/summary views for the entire society

### 2. Treasurer
**Role**: Finance-focused role for collections and expenses
**Access Level**: Financial management access

#### Permissions
- ✅ View financial overview (total collections, total expenses, current balance)
- ✅ View all residents' balances and dues
- ✅ Add collections/payments received from residents
- ✅ Edit or correct collection entries
- ✅ Add expenses (electricity bill, sewage repair, street light repair, other maintenance)
- ✅ View complaints overview
- ✅ Generate/export financial reports
- ❌ Change society-level charges structure
- ❌ Add/remove residents or change their personal details
- ❌ Change complaint statuses
- ❌ Approve expense entries
- ❌ Access configuration or admin sections

### 3. Resident
**Role**: End user living in the society
**Access Level**: Personal account access

#### Permissions
- ✅ View profile (flat number, name, contact details)
- ✅ View payment history (their own payments only)
- ✅ View current outstanding dues and next due date
- ✅ View services assigned to them (parking allocation, extra services, etc.)
- ✅ Create new complaints
- ✅ View and track the status of their own complaints only
- ✅ View upcoming and past meetings' basic info (date, time, agenda, minutes if shared)
- ❌ View complaints of other residents
- ❌ Change society charges, expenses, or collections
- ❌ Access configuration or admin sections

## Implementation Details

### Frontend Implementation

The RBAC system is implemented primarily on the frontend with the following components:

1. **Authentication Simulation**
   - Uses localStorage to store user role information
   - Simulates login/logout functionality for demonstration purposes

2. **Permission System**
   - Defined in `app.js` as a JavaScript object mapping roles to permissions
   - Each permission is represented as a boolean value

3. **UI Adaptation**
   - Dashboards are customized based on user role
   - Permission indicators show what actions are allowed/denied
   - Restricted sections are hidden or disabled based on role
   - Visual cues (icons, colors) differentiate between roles

4. **Role-Specific Dashboards**
   - President Dashboard: Full access to all administrative functions
   - Treasurer Dashboard: Focused on financial management
   - Resident Dashboard: Personal account information and services

### Permission Enforcement

Permissions are enforced through:

1. **UI Visibility Control**
   - Certain sections are hidden for roles that don't have access
   - Elements are marked with CSS classes indicating role restrictions

2. **Action Blocking**
   - JavaScript checks user role before executing sensitive actions
   - Unauthorized actions are either blocked or show error messages

3. **Visual Indicators**
   - Permission badges show access level for each feature
   - Lock icons indicate restricted areas
   - Color-coded role identification

## Testing

### Test Pages

Several test pages have been created to demonstrate and verify the RBAC system:

1. `permissions-test.html` - Comprehensive permission matrix display
2. `role-access-demo.html` - Interactive role permission explorer
3. Footer test buttons (visible only on localhost) for quick role switching

### Test Functions

The `role-test.js` file provides helper functions for testing:

- `testRoleAccess(role)` - Simulate login as a specific role
- `clearRoleTest()` - Clear authentication data
- `getCurrentRole()` - Check currently authenticated role
- `verifyPermissions()` - Display current role permissions in console

## Future Enhancements

### Backend Integration

For a production implementation, the RBAC system would be enhanced with:

1. **Server-Side Validation**
   - API endpoints would check user permissions before processing requests
   - Database-level access controls

2. **Persistent Authentication**
   - JWT tokens for secure session management
   - Role information stored in user database records

3. **Dynamic Permission Management**
   - Admin interface for defining custom roles
   - Granular permission assignment

4. **Audit Logging**
   - Track user actions for security and compliance
   - Monitor unauthorized access attempts

## Conclusion

The RBAC implementation in MySociety Manager provides a clear separation of concerns between different user roles while maintaining a consistent and intuitive user experience. The system ensures that users can only access features relevant to their responsibilities, enhancing both security and usability.