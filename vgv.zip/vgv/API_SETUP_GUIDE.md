# MySociety Manager API Setup Guide

This guide explains how to set up and use the API for the MySociety Manager application.

## Prerequisites

1. Node.js (version 12 or higher)
2. npm (comes with Node.js)

## Installation Steps

### 1. Install Dependencies

Navigate to the project directory and install the required packages:

```bash
cd path/to/vgv
npm install
```

This will install Express and body-parser, which are required for the API.

### 2. Start the Server

Run the server using Node.js:

```bash
node server/index.js
```

The server will start on port 3000 by default. You should see output similar to:

```
Server is running on http://localhost:3000
API endpoints:
  POST /api/societies/register
  POST /api/auth/president/login
  POST /api/auth/treasurer/login
  POST /api/auth/resident/login
  GET /api/societies/:id
  GET /api/societies/:id/residents
```

## API Endpoints

### 1. Society Registration

**Endpoint:** `POST /api/societies/register`

Registers a new housing society.

**Request Body:**
```json
{
  "societyName": "Green Valley Apartments",
  "address": "123 Main Street",
  "city": "Sample City",
  "numberOfFlats": 50,
  "presidentName": "John Smith",
  "presidentEmail": "john@example.com",
  "presidentMobile": "+1234567890",
  "password": "securepassword"
}
```

**Response (Success):**
```json
{
  "success": true,
  "message": "Society registered successfully!",
  "society": {
    "id": 1234,
    "societyName": "Green Valley Apartments",
    "address": "123 Main Street",
    "city": "Sample City",
    "numberOfFlats": 50,
    "presidentName": "John Smith",
    "presidentEmail": "john@example.com",
    "presidentMobile": "+1234567890",
    "createdAt": "2023-06-15T10:30:00.000Z"
  }
}
```

**Response (Error):**
```json
{
  "success": false,
  "message": "All fields are required"
}
```

### 2. President Login

**Endpoint:** `POST /api/auth/president/login`

Authenticates a society president.

**Request Body:**
```json
{
  "email": "john@example.com",
  "password": "securepassword"
}
```

**Response (Success):**
```json
{
  "success": true,
  "message": "Login successful",
  "user": {
    "id": 1,
    "name": "John Smith",
    "email": "john@example.com",
    "role": "president"
  },
  "token": "sample-jwt-token"
}
```

### 3. Treasurer Login

**Endpoint:** `POST /api/auth/treasurer/login`

Authenticates a society treasurer.

**Request Body:**
```json
{
  "email": "jane@example.com",
  "password": "securepassword"
}
```

**Response (Success):**
```json
{
  "success": true,
  "message": "Login successful",
  "user": {
    "id": 2,
    "name": "Jane Treasurer",
    "email": "jane@example.com",
    "role": "treasurer"
  },
  "token": "sample-jwt-token"
}
```

### 4. Resident Login

**Endpoint:** `POST /api/auth/resident/login`

Authenticates a resident.

**Request Body:**
```json
{
  "email": "sarah@example.com",
  "password": "securepassword"
}
```

**Response (Success):**
```json
{
  "success": true,
  "message": "Login successful",
  "user": {
    "id": 3,
    "name": "Sarah Johnson",
    "email": "sarah@example.com",
    "role": "resident",
    "flat": "A-102"
  },
  "token": "sample-jwt-token"
}
```

### 5. Get Society Details

**Endpoint:** `GET /api/societies/:id`

Retrieves details of a specific society.

**Response (Success):**
```json
{
  "success": true,
  "society": {
    "id": "123",
    "name": "Green Valley Apartments",
    "address": "123 Main Street",
    "city": "Sample City",
    "numberOfFlats": 50,
    "president": {
      "name": "John Smith",
      "email": "john@example.com",
      "phone": "+1234567890"
    }
  }
}
```

### 6. Get Residents

**Endpoint:** `GET /api/societies/:id/residents`

Retrieves all residents of a society.

**Response (Success):**
```json
{
  "success": true,
  "residents": [
    {
      "flat": "A-101",
      "name": "John Smith",
      "totalCharges": 500,
      "paid": 500,
      "due": 0,
      "status": "paid"
    },
    {
      "flat": "A-102",
      "name": "Sarah Johnson",
      "totalCharges": 500,
      "paid": 300,
      "due": 200,
      "status": "partial"
    }
  ]
}
```

## Frontend Integration

The frontend JavaScript in `app.js` already includes functions to call these API endpoints:

1. `registerSociety()` - Calls `/api/societies/register`
2. `loginPresident()` - Calls `/api/auth/president/login`
3. `loginTreasurer()` - Calls `/api/auth/treasurer/login`
4. `loginResident()` - Calls `/api/auth/resident/login`

These functions handle:
- Form data collection
- API requests with proper headers
- Response handling
- User feedback
- Loading states

## Database Integration

In a production environment, you would integrate with a database:

1. Replace the in-memory data storage with database queries
2. Implement proper password hashing (bcrypt recommended)
3. Add JWT token generation and validation
4. Implement proper error handling and logging
5. Add data validation and sanitization

Example database integration pseudocode:

```javascript
// Replace the society registration endpoint with:
app.post('/api/societies/register', async (req, res) => {
  try {
    const { societyName, address, city, numberOfFlats, presidentName, presidentEmail, presidentMobile, password } = req.body;
    
    // Validate input
    if (!societyName || !address || !city || !numberOfFlats || !presidentName || !presidentEmail || !presidentMobile || !password) {
      return res.status(400).json({ 
        success: false, 
        message: 'All fields are required' 
      });
    }
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);
    
    // Save to database
    const newSociety = await db.query(
      'INSERT INTO societies (name, address, city, number_of_flats, president_name, president_email, president_mobile, password_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [societyName, address, city, numberOfFlats, presidentName, presidentEmail, presidentMobile, hashedPassword]
    );
    
    res.status(201).json({ 
      success: true, 
      message: 'Society registered successfully!',
      society: {
        id: newSociety.insertId,
        societyName,
        address,
        city,
        numberOfFlats,
        presidentName,
        presidentEmail,
        presidentMobile
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});
```

## Security Considerations

1. Always use HTTPS in production
2. Implement rate limiting to prevent abuse
3. Use environment variables for sensitive data
4. Implement proper authentication middleware
5. Sanitize all user inputs
6. Regularly update dependencies

## Testing the API

You can test the API using tools like Postman or curl:

```bash
# Test society registration
curl -X POST http://localhost:3000/api/societies/register \
  -H "Content-Type: application/json" \
  -d '{
    "societyName": "Test Society",
    "address": "123 Test St",
    "city": "Test City",
    "numberOfFlats": 10,
    "presidentName": "Test President",
    "presidentEmail": "test@example.com",
    "presidentMobile": "1234567890",
    "password": "testpass123"
  }'

# Test president login
curl -X POST http://localhost:3000/api/auth/president/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "testpass123"
  }'
```