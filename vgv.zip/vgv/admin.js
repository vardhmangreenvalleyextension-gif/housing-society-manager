// Admin Dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check if admin is logged in
    checkAdminAuth();
    
    // Logout handler
    const adminLogout = document.getElementById('adminLogout');
    if (adminLogout) {
        adminLogout.addEventListener('click', function(e) {
            e.preventDefault();
            logoutAdmin();
        });
    }
    
    // Load dashboard data
    loadDashboardStats();
    loadSocietiesData();
    
    // Search and filter handlers
    const societySearch = document.getElementById('societySearch');
    const societyFilter = document.getElementById('societyFilter');
    
    if (societySearch) {
        societySearch.addEventListener('input', debounce(filterSocieties, 300));
    }
    
    if (societyFilter) {
        societyFilter.addEventListener('change', filterSocieties);
    }
    
    // Pagination handlers
    const prevPage = document.getElementById('prevPage');
    const nextPage = document.getElementById('nextPage');
    
    if (prevPage) {
        prevPage.addEventListener('click', function() {
            changePage(-1);
        });
    }
    
    if (nextPage) {
        nextPage.addEventListener('click', function() {
            changePage(1);
        });
    }
});

// Current page state
let currentPage = 1;
let currentSearch = '';
let currentFilter = 'all';

// Check if admin is authenticated
function checkAdminAuth() {
    const adminAuth = localStorage.getItem('admin_auth');
    if (!adminAuth) {
        // Redirect to login page
        window.location.href = '/admin-login.html';
    }
}

// Logout admin
function logoutAdmin() {
    localStorage.removeItem('admin_auth');
    window.location.href = '/';
}

// Load dashboard statistics
function loadDashboardStats() {
    // TODO: Fetch real data from API
    // For now, using mock data
    document.getElementById('totalSocieties').textContent = '24';
    document.getElementById('totalResidents').textContent = '1,248';
    document.getElementById('newRegistrations').textContent = '3';
    document.getElementById('activeAdmins').textContent = '5';
}

// Load societies data
function loadSocietiesData() {
    fetch(`/api/societies`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                renderSocietiesTable(data.societies);
            } else {
                console.error('Failed to load societies:', data.message);
            }
        })
        .catch(error => {
            console.error('Error loading societies:', error);
            // Fallback to mock data
            renderSocietiesTable(mockSocieties);
        });
}

// Render societies table
function renderSocietiesTable(societies) {
    const tbody = document.getElementById('societiesTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    if (societies.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `<td colspan="8" style="text-align: center;">No societies found</td>`;
        tbody.appendChild(row);
        return;
    }
    
    societies.forEach(society => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${society.id}</td>
            <td>${society.societyName}</td>
            <td>${society.address}</td>
            <td>${society.city}</td>
            <td>${society.numberOfFlats}</td>
            <td>${society.presidentName}</td>
            <td>${new Date(society.createdAt).toLocaleDateString()}</td>
            <td>
                <button class="btn btn-outline view-details" data-id="${society.id}">View</button>
                <button class="btn btn-secondary delete-society" data-id="${society.id}">Delete</button>
            </td>
        `;
        tbody.appendChild(row);
    });
    
    // Add event listeners to action buttons
    document.querySelectorAll('.view-details').forEach(button => {
        button.addEventListener('click', function() {
            const societyId = this.getAttribute('data-id');
            viewSocietyDetails(societyId);
        });
    });
    
    document.querySelectorAll('.delete-society').forEach(button => {
        button.addEventListener('click', function() {
            const societyId = this.getAttribute('data-id');
            deleteSociety(societyId);
        });
    });
}

// Filter societies based on search and filter criteria
function filterSocieties() {
    currentSearch = document.getElementById('societySearch').value;
    currentFilter = document.getElementById('societyFilter').value;
    currentPage = 1; // Reset to first page when filtering
    
    const queryParams = new URLSearchParams({
        search: currentSearch,
        filter: currentFilter,
        page: currentPage,
        limit: 5
    });
    
    fetch(`/api/societies/search?${queryParams}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                renderSocietiesTable(data.societies);
                updatePagination(data);
            } else {
                console.error('Failed to search societies:', data.message);
            }
        })
        .catch(error => {
            console.error('Error searching societies:', error);
        });
}

// Change page
function changePage(direction) {
    currentPage += direction;
    if (currentPage < 1) currentPage = 1;
    
    const queryParams = new URLSearchParams({
        search: currentSearch,
        filter: currentFilter,
        page: currentPage,
        limit: 5
    });
    
    fetch(`/api/societies/search?${queryParams}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                renderSocietiesTable(data.societies);
                updatePagination(data);
            } else {
                console.error('Failed to search societies:', data.message);
            }
        })
        .catch(error => {
            console.error('Error searching societies:', error);
        });
}

// Update pagination controls
function updatePagination(data) {
    const pageInfo = document.getElementById('pageInfo');
    if (pageInfo) {
        pageInfo.textContent = `Page ${data.currentPage} of ${data.totalPages}`;
    }
    
    const prevBtn = document.getElementById('prevPage');
    const nextBtn = document.getElementById('nextPage');
    
    if (prevBtn) {
        prevBtn.disabled = data.currentPage === 1;
    }
    
    if (nextBtn) {
        nextBtn.disabled = data.currentPage === data.totalPages;
    }
}

// Debounce function to limit API calls
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// View society details
function viewSocietyDetails(societyId) {
    // TODO: Fetch and display society details
    alert(`Viewing details for society ID: ${societyId}\nThis would show detailed society information in production.`);
}

// Delete society
function deleteSociety(societyId) {
    if (confirm(`Are you sure you want to delete society ${societyId}? This action cannot be undone.`)) {
        // TODO: Implement delete functionality with API
        alert(`Deleting society ${societyId}...\nThis would connect to backend API in production.`);
        // Reload data after deletion
        filterSocieties();
    }
}

// Mock data for demonstration
const mockSocieties = [
    {
        id: 'SOC001',
        societyName: 'Green Valley Apartments',
        address: '123 Main Street',
        city: 'Mumbai',
        numberOfFlats: 50,
        presidentName: 'John Smith',
        createdAt: '2023-05-15T10:30:00Z'
    },
    {
        id: 'SOC002',
        societyName: 'Sunshine Residency',
        address: '456 Park Avenue',
        city: 'Delhi',
        numberOfFlats: 75,
        presidentName: 'Priya Sharma',
        createdAt: '2023-05-18T14:45:00Z'
    },
    {
        id: 'SOC003',
        societyName: 'Lake View Colony',
        address: '789 Lake Road',
        city: 'Bangalore',
        numberOfFlats: 120,
        presidentName: 'Rajesh Kumar',
        createdAt: '2023-05-20T09:15:00Z'
    },
    {
        id: 'SOC004',
        societyName: 'Skyline Towers',
        address: '101 Sky Street',
        city: 'Hyderabad',
        numberOfFlats: 90,
        presidentName: 'Anita Desai',
        createdAt: '2023-05-22T16:20:00Z'
    },
    {
        id: 'SOC005',
        societyName: 'Garden Plaza',
        address: '202 Garden Lane',
        city: 'Chennai',
        numberOfFlats: 65,
        presidentName: 'Vikram Patel',
        createdAt: '2023-05-25T11:30:00Z'
    }
];