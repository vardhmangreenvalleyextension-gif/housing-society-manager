// Simple test server to verify API routes
const express = require('express');
const app = express();
const PORT = 3001;

// Simple API route
app.get('/api/test', (req, res) => {
    res.json({ message: 'API is working!' });
});

// Simple static file serving
app.use(express.static('.'));

app.listen(PORT, () => {
    console.log(`Test server running on http://localhost:${PORT}`);
    console.log(`Test API endpoint: http://localhost:${PORT}/api/test`);
});