// DOM Elements
document.addEventListener('DOMContentLoaded', function() {
    // Mobile Navigation Toggle
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    
    if (hamburger && navLinks) {
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
    }
    
    // Tab Switching in Auth Section
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active class from all buttons and panes
            tabBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            
            // Add active class to clicked button
            btn.classList.add('active');
            
            // Show corresponding pane
            const tabId = btn.getAttribute('data-tab');
            document.getElementById(`${tabId}-tab`).classList.add('active');
        });
    });
    
    // Role Selection in Login
    const roleCards = document.querySelectorAll('.role-card');
    const roleForms = document.querySelectorAll('.role-form');
    
    roleCards.forEach(card => {
        card.addEventListener('click', () => {
            // Remove active class from all cards
            roleCards.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked card
            card.classList.add('active');
            
            // Hide all forms
            roleForms.forEach(form => {
                form.style.display = 'none';
            });
            
            // Show corresponding form
            const role = card.getAttribute('data-role');
            document.getElementById(`${role}-login`).style.display = 'block';
        });
    });
    
    // Set default active role form
    if (roleForms.length > 0) {
        roleForms[0].style.display = 'block';
    }
    
    // Form Submissions
    // President Login Form
    const presidentLoginForm = document.getElementById('presidentLoginForm');
    if (presidentLoginForm) {
        presidentLoginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(presidentLoginForm);
            const loginData = {
                email: formData.get('email'),
                password: formData.get('password')
            };
            loginPresident(loginData);
        });
    }
    
    // Treasurer Login Form
    const treasurerLoginForm = document.getElementById('treasurerLoginForm');
    if (treasurerLoginForm) {
        treasurerLoginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(treasurerLoginForm);
            const loginData = {
                email: formData.get('email'),
                password: formData.get('password')
            };
            loginTreasurer(loginData);
        });
    }
    
    // Resident Login Form
    const residentLoginForm = document.getElementById('residentLoginForm');
    if (residentLoginForm) {
        residentLoginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(residentLoginForm);
            const loginData = {
                email: formData.get('email'),
                password: formData.get('password')
            };
            loginResident(loginData);
        });
    }
    
    // Society Registration Form
    const societyRegistrationForm = document.getElementById('societyRegistrationForm');
    if (societyRegistrationForm) {
        societyRegistrationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(societyRegistrationForm);
            const societyData = {
                societyName: formData.get('societyName'),
                address: formData.get('address'),
                city: formData.get('city'),
                numberOfFlats: formData.get('numberOfFlats'),
                presidentName: formData.get('presidentName'),
                presidentEmail: formData.get('presidentEmail'),
                presidentMobile: formData.get('presidentMobile'),
                password: formData.get('password')
            };
            
            // Register society via API
            registerSociety(societyData);
        });
    }
    

    
    // Add Expense Category Form
    const addExpenseCategoryBtn = document.getElementById('addExpenseCategoryBtn');
    if (addExpenseCategoryBtn) {
        addExpenseCategoryBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const categoryNameInput = document.getElementById('expenseCategoryName');
            const categoryDescriptionInput = document.getElementById('expenseCategoryDescription');
            
            const categoryName = categoryNameInput.value.trim();
            const categoryDescription = categoryDescriptionInput.value.trim();
            
            if (!categoryName) {
                alert('Please enter a category name');
                return;
            }
            
            // Add to categories table
            addExpenseCategoryToTable(categoryName, categoryDescription);
            
            // Save to localStorage
            saveExpenseCategory(categoryName, categoryDescription);
            
            // Update expense form category dropdown
            updateExpenseCategoryDropdown();
            
            // In a real app, you would send this data to the server
            alert(`Category added successfully!\nName: ${categoryName}\nDescription: ${categoryDescription}`);
            
            // Reset form
            categoryNameInput.value = '';
            categoryDescriptionInput.value = '';
        });
    }
    
    // Add Expense Form
    const addExpenseForm = document.querySelector('#president-dashboard .expenses-form');
    if (addExpenseForm) {
        const addExpenseBtn = addExpenseForm.querySelector('.btn-primary');
        if (addExpenseBtn) {
            addExpenseBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const date = addExpenseForm.querySelector('input[type="date"]').value;
                const category = addExpenseForm.querySelector('select').value;
                const amount = addExpenseForm.querySelector('input[placeholder="Enter amount"]').value;
                const notes = addExpenseForm.querySelector('input[placeholder="Additional notes"]').value;
                
                // Add to expenses table
                addExpenseToTable(date, category, amount, notes);
                
                // Save to localStorage
                saveExpense(date, category, amount, notes);
                
                // In a real app, you would send this data to the server
                alert(`Expense added successfully!
Date: ${date}
Category: ${category}
Amount: ₹${amount}
Notes: ${notes}`);
                
                // Reset form
                addExpenseForm.reset();
            });
        }
    }
    
    // Schedule Meeting Form
    const scheduleMeetingForm = document.querySelector('#president-dashboard .meetings-form');
    if (scheduleMeetingForm) {
        const scheduleMeetingBtn = scheduleMeetingForm.querySelector('.btn-primary');
        if (scheduleMeetingBtn) {
            scheduleMeetingBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const date = scheduleMeetingForm.querySelector('input[type="date"]').value;
                const time = scheduleMeetingForm.querySelector('input[type="time"]').value;
                const agenda = scheduleMeetingForm.querySelector('input[placeholder="Meeting agenda"]').value;
                
                // Add to both president and resident meetings tables
                addMeetingToTable(date, time, agenda);
                
                // Save to localStorage
                saveMeeting(date, time, agenda);
                
                // In a real app, you would send this data to the server
                alert(`Meeting scheduled successfully!
Date: ${date}
Time: ${time}
Agenda: ${agenda}`);
                
                // Reset form
                scheduleMeetingForm.reset();
            });
        }
    }
    
    // Add Collection Form (Treasurer Dashboard)
    const addCollectionForm = document.querySelector('#treasurer-dashboard .collections-form');
    if (addCollectionForm) {
        const addCollectionBtn = addCollectionForm.querySelector('.btn-primary');
        if (addCollectionBtn) {
            addCollectionBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const date = addCollectionForm.querySelector('input[type="date"]').value;
                const flatNumber = addCollectionForm.querySelector('input[placeholder="Flat number"]').value;
                const amount = addCollectionForm.querySelector('input[placeholder="Enter amount"]').value;
                const mode = addCollectionForm.querySelector('select').value;
                const remarks = addCollectionForm.querySelector('input[placeholder="Additional remarks"]').value;
                
                // Validate inputs
                if (!date || !flatNumber || !amount) {
                    alert('Please fill in all required fields');
                    return;
                }
                
                // Add to collections table
                addCollectionToTable(date, flatNumber, amount, mode, remarks);
                
                // Save to localStorage
                saveCollection(date, flatNumber, amount, mode, remarks);
                
                // Update resident's last payment date
                updateResidentLastPayment(flatNumber, date);
                
                // Refresh Residents & Balances table in president dashboard
                setTimeout(populateResidentsBalancesTable, 100);
                
                // Also update resident dues display in resident portal if visible
                const residentDashboard = document.getElementById('resident-dashboard');
                if (residentDashboard && residentDashboard.style.display !== 'none') {
                    // Check if this collection is for the currently logged in resident
                    const authData = localStorage.getItem(AUTH_KEY);
                    if (authData) {
                        const userData = JSON.parse(authData);
                        if (userData.role === 'resident' && userData.username === flatNumber) {
                            // Update resident dues
                            setTimeout(() => {
                                const savedResidents = localStorage.getItem('residents');
                                if (savedResidents) {
                                    const residents = JSON.parse(savedResidents);
                                    const resident = residents.find(r => r.flatNumber === flatNumber);
                                    if (resident) {
                                        updateResidentDues(resident.services || []);
                                    }
                                }
                            }, 150);
                        }
                    }
                }
                
                // In a real app, you would send this data to the server
                alert(`Collection added successfully!
Date: ${date}
Flat: ${flatNumber}
Amount: ₹${amount}
Mode: ${mode}
Remarks: ${remarks}`);
                
                // Reset form
                addCollectionForm.reset();
            });
        }
    }
    
    // Bank Transaction Form (Treasurer Dashboard)
    const addBankTransactionBtn = document.getElementById('addBankTransactionBtn');
    const cancelBankTransactionBtn = document.getElementById('cancelBankTransactionBtn');
    const saveBankTransactionBtn = document.getElementById('saveBankTransactionBtn');
    const addBankTransactionForm = document.getElementById('addBankTransactionForm');
    
    if (addBankTransactionBtn) {
        addBankTransactionBtn.addEventListener('click', function() {
            addBankTransactionForm.style.display = 'block';
        });
    }
    
    if (cancelBankTransactionBtn) {
        cancelBankTransactionBtn.addEventListener('click', function() {
            addBankTransactionForm.style.display = 'none';
            // Reset form
            document.getElementById('transactionDate').value = '';
            document.getElementById('transactionAmount').value = '';
            document.getElementById('transactionReason').value = '';
            document.getElementById('transactionType').value = 'credit';
            document.getElementById('transactionMode').value = 'Cash';
        });
    }
    
    if (saveBankTransactionBtn) {
        saveBankTransactionBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const date = document.getElementById('transactionDate').value;
            const type = document.getElementById('transactionType').value;
            const amount = document.getElementById('transactionAmount').value;
            const mode = document.getElementById('transactionMode').value;
            const reason = document.getElementById('transactionReason').value;
            
            // Validate inputs
            if (!date || !amount || !reason) {
                alert('Please fill in all required fields (Date, Amount, and Reason)');
                return;
            }
            
            // Update financial accounts
            updateFinancialAccounts(amount, mode, type, reason);
            
            // Add to bank transactions table
            addBankTransactionToTable(date, type, amount, mode, reason);
            
            // Hide form and reset
            addBankTransactionForm.style.display = 'none';
            document.getElementById('transactionDate').value = '';
            document.getElementById('transactionAmount').value = '';
            document.getElementById('transactionReason').value = '';
            document.getElementById('transactionType').value = 'credit';
            document.getElementById('transactionMode').value = 'Cash';
            
            alert(`Bank transaction added successfully!`);
        });
    }
    
    // Past Meetings Form (President Dashboard)
    const addPastMeetingBtn = document.getElementById('addPastMeetingBtn');
    const cancelPastMeetingBtn = document.getElementById('cancelPastMeetingBtn');
    const savePastMeetingBtn = document.getElementById('savePastMeetingBtn');
    const addPastMeetingForm = document.getElementById('addPastMeetingForm');
    
    if (addPastMeetingBtn) {
        addPastMeetingBtn.addEventListener('click', function() {
            addPastMeetingForm.style.display = 'block';
        });
    }
    
    if (cancelPastMeetingBtn) {
        cancelPastMeetingBtn.addEventListener('click', function() {
            addPastMeetingForm.style.display = 'none';
            // Reset form
            document.getElementById('pastMeetingDate').value = '';
            document.getElementById('pastMeetingAgenda').value = '';
            document.getElementById('pastMeetingMinutes').value = '';
            document.getElementById('pastMeetingDocument').value = '';
        });
    }
    
    if (savePastMeetingBtn) {
        savePastMeetingBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const date = document.getElementById('pastMeetingDate').value;
            const agenda = document.getElementById('pastMeetingAgenda').value;
            const minutes = document.getElementById('pastMeetingMinutes').value;
            const documentInput = document.getElementById('pastMeetingDocument');
            
            // Validate inputs
            if (!date || !agenda) {
                alert('Please fill in all required fields (Date and Agenda)');
                return;
            }
            
            // Handle document upload
            let documentData = null;
            let documentName = null;
            
            if (documentInput.files && documentInput.files[0]) {
                const file = documentInput.files[0];
                documentName = file.name;
                
                // For simplicity, we'll store a placeholder - in a real app you'd handle file upload properly
                documentData = 'uploaded_document_placeholder';
            }
            
            // Add to past meetings table
            addPastMeetingToTable(date, agenda, minutes, documentName);
            
            // Save to localStorage
            savePastMeeting(date, agenda, minutes, documentName, documentData);
            
            // Hide form and reset
            addPastMeetingForm.style.display = 'none';
            document.getElementById('pastMeetingDate').value = '';
            document.getElementById('pastMeetingAgenda').value = '';
            document.getElementById('pastMeetingMinutes').value = '';
            document.getElementById('pastMeetingDocument').value = '';
            
            alert('Past meeting added successfully!');
        });
    }
    
    // Add Resident Form (Modal)
    const addResidentBtn = document.getElementById('addResidentBtn');
    const residentModal = document.getElementById('residentModal');
    const closeResidentModal = document.getElementById('closeResidentModal');
    const cancelResidentBtn = document.getElementById('cancelResidentBtn');
    const residentForm = document.getElementById('residentForm');
    
    // Open resident modal
    if (addResidentBtn) {
        addResidentBtn.addEventListener('click', function() {
            // Reset form
            if (residentForm) residentForm.reset();
            document.getElementById('residentId').value = '';
            document.getElementById('residentModalTitle').textContent = 'Add New Resident';
            if (residentModal) residentModal.style.display = 'block';
        });
    }
    
    // Close resident modal
    if (closeResidentModal) {
        closeResidentModal.addEventListener('click', function() {
            if (residentModal) residentModal.style.display = 'none';
        });
    }
    
    if (cancelResidentBtn) {
        cancelResidentBtn.addEventListener('click', function() {
            if (residentModal) residentModal.style.display = 'none';
        });
    }
    
    // Handle resident form submission
    if (residentForm) {
        residentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const residentId = document.getElementById('residentId').value;
            const flatNumber = document.getElementById('flatNumber').value;
            const residentName = document.getElementById('residentName').value;
            const residentEmail = document.getElementById('residentEmail').value;
            const residentPhone = document.getElementById('residentPhone').value;
            
            // Collect selected services
            const serviceCheckboxes = document.querySelectorAll('input[name="residentServices"]:checked');
            const services = Array.from(serviceCheckboxes).map(cb => cb.value);
            
            if (residentId) {
                // Update existing resident
                // Find the row to update
                const residentsTable = document.getElementById('residentsTable');
                if (residentsTable) {
                    const rows = residentsTable.querySelectorAll('tbody tr');
                    let targetRow = null;
                    rows.forEach(row => {
                        const flatCell = row.querySelector('td:first-child');
                        if (flatCell && flatCell.textContent === residentId) {
                            targetRow = row;
                        }
                    });
                    
                    if (targetRow) {
                        updateResidentInTable(targetRow, flatNumber, residentName, residentEmail, residentPhone, services);
                        updateResident(residentId, flatNumber, residentName, residentEmail, residentPhone, services);
                        alert(`Resident updated successfully!
Flat: ${flatNumber}
Name: ${residentName}
Email: ${residentEmail}
Phone: ${residentPhone}
Services: ${services.join(', ') || 'None'}`);
                    }
                }
            } else {
                // Add new resident
                addResidentToTable(flatNumber, residentName, residentEmail, residentPhone, services);
                saveResident(flatNumber, residentName, residentEmail, residentPhone, services);
                alert(`Resident added successfully!
Flat: ${flatNumber}
Name: ${residentName}
Email: ${residentEmail}
Phone: ${residentPhone}
Services: ${services.join(', ') || 'None'}`);
            }
            
            // Close modal
            if (residentModal) residentModal.style.display = 'none';
            
            // Refresh resident services display if resident dashboard is visible
            if (document.getElementById('resident-dashboard').style.display !== 'none') {
                setTimeout(displayResidentServices, 100);
                // Also update dues display
                setTimeout(() => {
                    const authData = localStorage.getItem(AUTH_KEY);
                    if (authData) {
                        const userData = JSON.parse(authData);
                        if (userData.role === 'resident' && userData.username === flatNumber) {
                            updateResidentDues(services);
                        }
                    }
                }, 150);
            }
        });
    }
    
    // Add Service Form (Modal)
    const addServiceBtn = document.getElementById('addServiceBtn');
    const serviceModal = document.getElementById('serviceModal');
    const closeServiceModal = document.getElementById('closeServiceModal');
    const cancelServiceBtn = document.getElementById('cancelServiceBtn');
    const serviceForm = document.getElementById('serviceForm');
    
    // Service Request Button
    const requestServiceBtn = document.getElementById('requestServiceBtn');
    if (requestServiceBtn) {
        requestServiceBtn.addEventListener('click', handleServiceRequest);
    }
    
    // Open service modal
    if (addServiceBtn) {
        addServiceBtn.addEventListener('click', function() {
            // Reset form
            if (serviceForm) serviceForm.reset();
            document.getElementById('serviceId').value = '';
            document.getElementById('serviceModalTitle').textContent = 'Add New Service';
            if (serviceModal) serviceModal.style.display = 'block';
        });
    }
    
    // Close service modal
    if (closeServiceModal) {
        closeServiceModal.addEventListener('click', function() {
            if (serviceModal) serviceModal.style.display = 'none';
        });
    }
    
    if (cancelServiceBtn) {
        cancelServiceBtn.addEventListener('click', function() {
            if (serviceModal) serviceModal.style.display = 'none';
        });
    }
    
    // Handle service form submission
    if (serviceForm) {
        serviceForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const serviceId = document.getElementById('serviceId').value;
            const serviceName = document.getElementById('serviceName').value;
            const serviceDescription = document.getElementById('serviceDescription').value;
            const serviceCharge = document.getElementById('serviceCharge').value;
            const serviceFrequency = document.getElementById('serviceFrequency').value;
            const serviceType = document.getElementById('serviceType').value;
            
            if (serviceId) {
                // Update existing service
                updateServiceInTable(serviceId, serviceName, serviceDescription, serviceCharge, serviceFrequency, serviceType);
                updateService(serviceId, serviceName, serviceDescription, serviceCharge, serviceFrequency, serviceType);
                alert(`Service updated successfully!
Name: ${serviceName}
Description: ${serviceDescription}
Charge: $${serviceCharge}
Frequency: ${serviceFrequency}
Type: ${serviceType}`);
            } else {
                // Add new service
                addServiceToTable(serviceName, serviceDescription, serviceCharge, serviceFrequency, serviceType);

                // Save to localStorage
                saveService(serviceName, serviceDescription, serviceCharge, serviceFrequency, serviceType);
                alert(`Service added successfully!
Name: ${serviceName}
Description: ${serviceDescription}
Charge: $${serviceCharge}
Frequency: ${serviceFrequency}
Type: ${serviceType}`);
            }
            
            // Close modal
            if (serviceModal) serviceModal.style.display = 'none';
            
            // Refresh displays that might be affected
            if (document.getElementById('resident-dashboard').style.display !== 'none') {
                setTimeout(displayResidentServices, 100);
            }
            if (document.getElementById('president-dashboard').style.display !== 'none') {
                setTimeout(displayServiceRequests, 100);
            }
        });
    }
    
    // Event delegation for service edit and delete buttons
    const servicesTable = document.getElementById('servicesTable');
    if (servicesTable) {
        servicesTable.addEventListener('click', function(e) {
            // Handle edit button clicks
            if (e.target.classList.contains('edit-service')) {
                const serviceId = e.target.getAttribute('data-service-id');
                if (serviceId) {
                    // Get service data from localStorage
                    const savedServices = localStorage.getItem('services');
                    if (savedServices) {
                        const services = JSON.parse(savedServices);
                        const service = services.find(s => s.id === serviceId);
                        if (service) {
                            editService(serviceId, service.name, service.description, service.charge, service.frequency, service.type);
                        }
                    }
                }
            }
            
            // Handle delete button clicks
            if (e.target.classList.contains('delete-service')) {
                if (confirm('Are you sure you want to delete this service?')) {
                    const serviceId = e.target.getAttribute('data-service-id');
                    if (serviceId) {
                        // Remove from UI
                        const row = e.target.closest('tr');
                        if (row) {
                            row.remove();
                        }
                        
                        // Remove from localStorage
                        removeServiceFromStorage(serviceId);
                    }
                }
            }
        });
    }
    
    // Complaint Management - President Dashboard
    // Attach event listeners to existing complaint status selects
    setTimeout(function() {
        const complaintStatusSelects = document.querySelectorAll('#president-dashboard .complaints-table .status-select');
        complaintStatusSelects.forEach(select => {
            select.addEventListener('change', function() {
                const complaintId = this.closest('tr').querySelector('td:first-child').textContent;
                const newStatus = this.value;
                updateComplaintStatus(complaintId, newStatus);
                
                // Update the status display in the resident dashboard if visible
                updateResidentComplaintStatus(complaintId, newStatus);
            });
        });
    }, 100);
    
    // Complaint Notes Management - President Dashboard
    setTimeout(function() {
        // Attach event listeners to save note buttons
        const saveNoteButtons = document.querySelectorAll('#president-dashboard .save-note');
        saveNoteButtons.forEach(button => {
            button.addEventListener('click', function() {
                const complaintId = this.getAttribute('data-complaint-id');
                const noteInput = this.closest('td').querySelector('.note-input');
                const noteText = noteInput.value.trim();
                
                if (complaintId && noteText) {
                    saveComplaintNote(complaintId, noteText);
                    alert(`Note saved for complaint ${complaintId}`);
                }
            });
        });
        
        // Load existing notes
        loadComplaintNotes();
    }, 100);
    
    // Complaint Management - Resident Dashboard
    const residentComplaintForm = document.querySelector('#resident-dashboard .complaints-form');
    if (residentComplaintForm) {
        const submitComplaintBtn = residentComplaintForm.querySelector('.btn-primary');
        if (submitComplaintBtn) {
            submitComplaintBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const category = residentComplaintForm.querySelector('select').value;
                const subject = residentComplaintForm.querySelector('input[placeholder="Brief subject"]').value;
                const description = residentComplaintForm.querySelector('textarea[placeholder="Detailed description of your complaint"]').value;
                
                // Add to both resident and president complaints tables
                const complaintId = addResidentComplaint(category, subject, description);
                
                if (complaintId) {
                    // Save to localStorage
                    saveResidentComplaint(category, subject, description);
                    
                    // In a real app, you would send this data to the server
                    alert(`Complaint submitted successfully!
Complaint ID: ${complaintId}
Category: ${category}
Subject: ${subject}
Description: ${description}`);
                } else {
                    alert('Failed to submit complaint. Please try again.');
                }
                
                // Reset form
                residentComplaintForm.reset();
            });
        }
    }
    
    // Close modals when clicking outside
    window.addEventListener('click', function(e) {
        if (residentModal && e.target === residentModal) {
            residentModal.style.display = 'none';
        }
        if (serviceModal && e.target === serviceModal) {
            serviceModal.style.display = 'none';
        }
    });
    
    // Load saved data on page load (after all event listeners are set up)
    // Only load if president dashboard is visible
    if (document.getElementById('president-dashboard').style.display !== 'none') {
        setTimeout(loadSavedData, 100);
    } else {
        // Also load saved data for other roles
        loadSavedData();
    }
    
    // Contact Form
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            // TODO: Add actual contact form submission logic here
            alert('Thank you for your message! We will get back to you soon.');
            contactForm.reset();
        });
    }
    
    // Logout buttons
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            simulateLogout();
        });
    }
    
    const logoutBtn2 = document.getElementById('logoutBtn2');
    if (logoutBtn2) {
        logoutBtn2.addEventListener('click', function() {
            simulateLogout();
        });
    }
    
    const logoutBtn3 = document.getElementById('logoutBtn3');
    if (logoutBtn3) {
        logoutBtn3.addEventListener('click', function() {
            simulateLogout();
        });
    }
    
    // Initialize charts
    initCharts();
    
    // Check for automatic billing on the 1st of the month
    checkAutomaticBilling();
    
    // Initialize financial accounts
    initializeFinancialAccounts();
    
    // Update financial displays
    updateFinancialDisplays();
    
    // Check permissions and update UI based on role
    checkPermissionsAndUI();
    
    // For testing purposes, expose the billing functions globally
    window.generateMonthlyBills = generateMonthlyBills;
    window.checkAutomaticBilling = checkAutomaticBilling;
    
    // Make sure resident services are displayed when the page loads
    const authData = localStorage.getItem(AUTH_KEY);
    if (authData) {
        const userData = JSON.parse(authData);
        if (userData.role === 'resident') {
            setTimeout(displayResidentServices, 100);
        }
    }
});

// Function to show dashboard based on role
function showDashboard(role) {
    // Hide all dashboards and main content
    document.getElementById('president-dashboard').style.display = 'none';
    document.getElementById('treasurer-dashboard').style.display = 'none';
    document.getElementById('resident-dashboard').style.display = 'none';
    document.querySelector('.navbar').style.display = 'none';
    
    // Hide main sections
    const mainSections = document.querySelectorAll('section:not(.dashboard)');
    mainSections.forEach(section => {
        section.style.display = 'none';
    });
    
    // Show the appropriate dashboard
    if (role === 'president') {
        document.getElementById('president-dashboard').style.display = 'block';
        // Display service requests and residents balances
        setTimeout(displayServiceRequests, 100);
        setTimeout(populateResidentsBalancesTable, 100);
    } else if (role === 'treasurer') {
        document.getElementById('treasurer-dashboard').style.display = 'block';
    } else if (role === 'resident') {
        document.getElementById('resident-dashboard').style.display = 'block';
        // Display resident services
        setTimeout(displayResidentServices, 100);
        // Also update dues display
        setTimeout(() => {
            const authData = localStorage.getItem(AUTH_KEY);
            if (authData) {
                const userData = JSON.parse(authData);
                const savedResidents = localStorage.getItem('residents');
                if (savedResidents && userData.username) {
                    const residents = JSON.parse(savedResidents);
                    const resident = residents.find(r => r.flatNumber === userData.username);
                    if (resident) {
                        updateResidentDues(resident.services || []);
                    }
                }
            }
        }, 150);
    }
    
    // Update UI based on permissions
    checkPermissionsAndUI();
    
    // Scroll to top
    window.scrollTo(0, 0);
}

// Function to hide all dashboards
function hideAllDashboards() {
    document.getElementById('president-dashboard').style.display = 'none';
    document.getElementById('treasurer-dashboard').style.display = 'none';
    document.getElementById('resident-dashboard').style.display = 'none';
    
    // Show main sections
    const mainSections = document.querySelectorAll('section:not(.dashboard)');
    mainSections.forEach(section => {
        section.style.display = 'block';
    });
}

// Check if it's the 1st of the month and trigger automatic billing
function checkAutomaticBilling() {
    const today = new Date();
    const day = today.getDate();
    
    // Check if it's the 1st day of the month
    if (day === 1) {
        // Check if we've already processed billing for this month
        const lastBillingKey = 'lastAutoBilling';
        const lastBilling = localStorage.getItem(lastBillingKey);
        const currentMonthYear = `${today.getFullYear()}-${today.getMonth()}`;
        
        if (lastBilling !== currentMonthYear) {
            // Generate automatic bills for all residents
            generateMonthlyBills();
            
            // Mark that we've processed billing for this month
            localStorage.setItem(lastBillingKey, currentMonthYear);
        }
    }
}

// Generate monthly bills for all residents
function generateMonthlyBills() {
    // Get all residents
    const savedResidents = localStorage.getItem('residents');
    if (!savedResidents) return;
    
    const residents = JSON.parse(savedResidents);
    
    // Get all services
    const savedServices = localStorage.getItem('services');
    const allServices = savedServices ? JSON.parse(savedServices) : [];
    
    // Process each resident
    residents.forEach(resident => {
        // Calculate monthly charges based on services
        let monthlyCharges = 0;
        
        // Add base maintenance charge
        monthlyCharges = 200; // Base maintenance from Maintenance service
        
        // Add charges for each service the resident has
        if (resident.services && Array.isArray(resident.services)) {
            resident.services.forEach(serviceName => {
                const serviceObj = allServices.find(s => s.name === serviceName);
                if (serviceObj) {
                    // Add the service charge
                    const charge = parseFloat(serviceObj.charge) || 0;
                    monthlyCharges += charge;
                }
            });
        }
        
        // If resident has maintenance service, subtract it since we already added base charge
        if (resident.services && resident.services.includes('Maintenance')) {
            // Find maintenance service charge and subtract it
            const maintenanceService = allServices.find(s => s.name === 'Maintenance');
            if (maintenanceService) {
                monthlyCharges -= parseFloat(maintenanceService.charge) || 0;
            }
        }
        
        // Create a billing record
        const billingRecord = {
            id: `bill-${resident.flatNumber}-${Date.now()}`,
            flatNumber: resident.flatNumber,
            residentName: resident.name,
            amount: monthlyCharges.toFixed(2),
            date: new Date().toISOString().split('T')[0],
            status: 'generated',
            description: 'Monthly service charges'
        };
        
        // Store the billing record
        saveBillingRecord(billingRecord);
    });
    
    // Show notification (in a real app, this might be an email or push notification)
    console.log('Monthly bills generated for all residents');
}

// Save billing record to localStorage
function saveBillingRecord(billingRecord) {
    const savedBills = localStorage.getItem('billingRecords');
    let bills = savedBills ? JSON.parse(savedBills) : [];
    
    // Add the new billing record
    bills.push(billingRecord);
    
    // Save back to localStorage
    localStorage.setItem('billingRecords', JSON.stringify(bills));
}

// Update billing record when a payment is made
function updateBillingRecordForPayment(flatNumber, amount, date) {
    const savedBills = localStorage.getItem('billingRecords');
    if (!savedBills) return;
    
    let bills = JSON.parse(savedBills);
    
    // Find unpaid bills for this resident
    const unpaidBills = bills.filter(bill => 
        bill.flatNumber === flatNumber && 
        bill.status === 'generated'
    );
    
    // If there are unpaid bills, update the most recent one
    if (unpaidBills.length > 0) {
        // Sort by date (newest first)
        unpaidBills.sort((a, b) => new Date(b.date) - new Date(a.date));
        
        // Update the most recent bill
        const recentBill = unpaidBills[0];
        const billIndex = bills.findIndex(bill => bill.id === recentBill.id);
        
        if (billIndex !== -1) {
            // Update status to paid
            bills[billIndex].status = 'paid';
            bills[billIndex].paymentDate = date;
            bills[billIndex].paymentAmount = amount;
            
            // Save back to localStorage
            localStorage.setItem('billingRecords', JSON.stringify(bills));
        }
    }
}

// Display billing history for a resident
function displayBillingHistory(flatNumber) {
    const billingHistoryContainer = document.getElementById('billingHistory');
    if (!billingHistoryContainer) return;
    
    // Get billing records
    const savedBills = localStorage.getItem('billingRecords');
    let bills = savedBills ? JSON.parse(savedBills) : [];
    
    // Filter bills for this resident
    const residentBills = bills.filter(bill => bill.flatNumber === flatNumber);
    
    // Sort by date (newest first)
    residentBills.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    // Display bills
    if (residentBills.length > 0) {
        let html = '<h3>Billing History</h3>';
        html += '<table class="data-table">';
        html += '<thead><tr><th>Date</th><th>Description</th><th>Amount</th><th>Status</th></tr></thead>';
        html += '<tbody>';
        
        residentBills.forEach(bill => {
            html += `<tr>`;
            html += `<td>${bill.date}</td>`;
            html += `<td>${bill.description}</td>`;
            html += `<td>₹${bill.amount}</td>`;
            html += `<td><span class="status ${bill.status}">${bill.status.charAt(0).toUpperCase() + bill.status.slice(1)}</span>`;
            
            // Add payment info if available
            if (bill.paymentDate) {
                html += `<br><small>Paid on ${bill.paymentDate} (₹${bill.paymentAmount})</small>`;
            }
            
            html += `</td>`;
            html += `</tr>`;
        });
        
        html += '</tbody></table>';
        billingHistoryContainer.innerHTML = html;
    } else {
        billingHistoryContainer.innerHTML = '<h3>Billing History</h3><p>No billing history available.</p>';
    }
}

// Initialize charts
function initCharts() {
    // Financial Chart for President
    const financialCtx = document.getElementById('financialChart');
    if (financialCtx) {
        new Chart(financialCtx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Collections',
                    data: [35000, 38000, 42000, 39000, 41000, 45000],
                    backgroundColor: 'rgba(52, 152, 219, 0.7)',
                    borderColor: 'rgba(52, 152, 219, 1)',
                    borderWidth: 1
                }, {
                    label: 'Expenses',
                    data: [12000, 11000, 13000, 12500, 11500, 12700],
                    backgroundColor: 'rgba(231, 76, 60, 0.7)',
                    borderColor: 'rgba(231, 76, 60, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // Expense Chart for President
    const expenseCtx = document.getElementById('expenseChart');
    if (expenseCtx) {
        new Chart(expenseCtx, {
            type: 'pie',
            data: {
                labels: ['Maintenance', 'Utilities', 'Repairs', 'Salaries', 'Miscellaneous'],
                datasets: [{
                    data: [35, 25, 20, 15, 5],
                    backgroundColor: [
                        'rgba(52, 152, 219, 0.7)',
                        'rgba(46, 204, 113, 0.7)',
                        'rgba(155, 89, 182, 0.7)',
                        'rgba(241, 196, 15, 0.7)',
                        'rgba(230, 126, 34, 0.7)'
                    ],
                    borderColor: [
                        'rgba(52, 152, 219, 1)',
                        'rgba(46, 204, 113, 1)',
                        'rgba(155, 89, 182, 1)',
                        'rgba(241, 196, 15, 1)',
                        'rgba(230, 126, 34, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        });
    }
    
    // Financial Chart for Treasurer
    const financialCtx2 = document.getElementById('financialChart2');
    if (financialCtx2) {
        new Chart(financialCtx2, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Collections',
                    data: [35000, 38000, 42000, 39000, 41000, 45000],
                    borderColor: 'rgba(52, 152, 219, 1)',
                    backgroundColor: 'rgba(52, 152, 219, 0.2)',
                    tension: 0.1
                }, {
                    label: 'Expenses',
                    data: [12000, 11000, 13000, 12500, 11500, 12700],
                    borderColor: 'rgba(231, 76, 60, 1)',
                    backgroundColor: 'rgba(231, 76, 60, 0.2)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // Expense Chart for Treasurer
    const expenseCtx2 = document.getElementById('expenseChart2');
    if (expenseCtx2) {
        new Chart(expenseCtx2, {
            type: 'doughnut',
            data: {
                labels: ['Maintenance', 'Utilities', 'Repairs', 'Salaries', 'Miscellaneous'],
                datasets: [{
                    data: [35, 25, 20, 15, 5],
                    backgroundColor: [
                        'rgba(52, 152, 219, 0.7)',
                        'rgba(46, 204, 113, 0.7)',
                        'rgba(155, 89, 182, 0.7)',
                        'rgba(241, 196, 15, 0.7)',
                        'rgba(230, 126, 34, 0.7)'
                    ],
                    borderColor: [
                        'rgba(52, 152, 219, 1)',
                        'rgba(46, 204, 113, 1)',
                        'rgba(155, 89, 182, 1)',
                        'rgba(241, 196, 15, 1)',
                        'rgba(230, 126, 34, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        });
    }
}

// Local Storage Simulation for Authentication
const AUTH_KEY = 'mysociety_auth';

// Check if user is already logged in
function checkAuthStatus() {
    const authData = localStorage.getItem(AUTH_KEY);
    if (authData) {
        const userData = JSON.parse(authData);
        showDashboard(userData.role);
    }
}

// Simulate login
function simulateLogin(role) {
    const userData = {
        role: role,
        timestamp: new Date().toISOString()
    };
    
    localStorage.setItem(AUTH_KEY, JSON.stringify(userData));
    showDashboard(role);
}

// Simulate logout
function simulateLogout() {
    localStorage.removeItem(AUTH_KEY);
    hideAllDashboards();
    // Scroll to auth section
    document.getElementById('auth').scrollIntoView();
}

// Register society via API
function registerSociety(societyData) {
    // Show loading indicator
    const submitButton = document.querySelector('#societyRegistrationForm .btn-primary');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Registering...';
    submitButton.disabled = true;
    
    // Actual API call
    fetch('/api/societies/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(societyData),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Society registered successfully!');
            // Reset form
            document.getElementById('societyRegistrationForm').reset();
            // Redirect to president dashboard
            simulateLogin('president');
        } else {
            alert('Registration failed: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Registration failed. Please try again.');
    })
    .finally(() => {
        // Restore button
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    });
}

// President login
function loginPresident(loginData) {
    const submitButton = document.querySelector('#presidentLoginForm .btn-primary');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Logging in...';
    submitButton.disabled = true;
    
    fetch('/api/auth/president/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(loginData),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('President login successful!');
            simulateLogin('president');
        } else {
            alert('Login failed: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Login failed. Please try again.');
    })
    .finally(() => {
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    });
}

// Treasurer login
function loginTreasurer(loginData) {
    const submitButton = document.querySelector('#treasurerLoginForm .btn-primary');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Logging in...';
    submitButton.disabled = true;
    
    fetch('/api/auth/treasurer/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(loginData),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Treasurer login successful!');
            simulateLogin('treasurer');
        } else {
            alert('Login failed: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Login failed. Please try again.');
    })
    .finally(() => {
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    });
}

// Resident login
function loginResident(loginData) {
    const submitButton = document.querySelector('#residentLoginForm .btn-primary');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Logging in...';
    submitButton.disabled = true;
    
    fetch('/api/auth/resident/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(loginData),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Resident login successful!');
            simulateLogin('resident');
        } else {
            alert('Login failed: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Login failed. Please try again.');
    })
    .finally(() => {
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    });
}

// Data Persistence Functions
// Load saved data on page load
function loadSavedData() {

    // Clear existing table data before loading from localStorage to prevent duplication
    
    // Clear expenses table
    const expensesTableBody = document.querySelector('#president-dashboard .expenses-form').nextElementSibling.querySelector('tbody');
    if (expensesTableBody) {
        expensesTableBody.innerHTML = '';
    }
    
    // Clear meetings table
    const meetingsTableBody = document.querySelector('#president-dashboard .meetings-form').nextElementSibling.querySelector('tbody');
    if (meetingsTableBody) {
        meetingsTableBody.innerHTML = '';
    }
    
    // Clear residents table
    const residentsTableBody = document.getElementById('residentsTable') ? document.getElementById('residentsTable').querySelector('tbody') : null;
    if (residentsTableBody) {
        residentsTableBody.innerHTML = '';
    }
    
    // Clear services table
    const servicesTableBody = document.getElementById('servicesTable') ? document.getElementById('servicesTable').querySelector('tbody') : null;
    if (servicesTableBody) {
        servicesTableBody.innerHTML = '';
    }
    
    // Initialize default services if not present
    if (!localStorage.getItem('services')) {
        const defaultServices = [
            { id: 'svc-1', name: 'Maintenance', description: 'Monthly maintenance fees', charge: 200, frequency: 'monthly', type: 'compulsory' },
            { id: 'svc-2', name: 'Parking', description: 'Monthly parking fees', charge: 50, frequency: 'monthly', type: 'optional' },
            { id: 'svc-3', name: 'Water', description: 'Monthly water supply fees', charge: 30, frequency: 'monthly', type: 'compulsory' },
            { id: 'svc-4', name: 'Light', description: 'Monthly electricity fees', charge: 20, frequency: 'monthly', type: 'compulsory' }
        ];
        localStorage.setItem('services', JSON.stringify(defaultServices));
    }
    
    // Load expenses
    const savedExpenses = localStorage.getItem('expenses');
    if (savedExpenses) {
        const expenses = JSON.parse(savedExpenses);
        expenses.forEach(expense => {
            addExpenseToTable(expense.date, expense.category, expense.amount, expense.notes);
        });
    }
    
    // Load meetings
    const savedMeetings = localStorage.getItem('meetings');
    if (savedMeetings) {
        const meetings = JSON.parse(savedMeetings);
        meetings.forEach(meeting => {
            // Add to both president and resident dashboards
            addMeetingToTable(meeting.date, meeting.time, meeting.agenda);
        });
    }
    
    // Load residents
    const savedResidents = localStorage.getItem('residents');
    if (savedResidents) {
        const residents = JSON.parse(savedResidents);
        residents.forEach(resident => {
            // Extract services if they exist, otherwise use empty array
            const services = resident.services || [];
            addResidentToTable(resident.flatNumber, resident.name, resident.email, resident.phone, services);
        });
    }
    
    // Load services
    const savedServices = localStorage.getItem('services');
    if (savedServices) {
        const services = JSON.parse(savedServices);
        services.forEach(service => {
            // Pass the service ID to maintain consistency
            const serviceType = service.type || 'optional';
            addServiceToTable(service.name, service.description, service.charge, service.frequency, serviceType, service.id);
        });
    }
    
    // Clear expense categories table
    const categoriesTableBody = document.getElementById('expenseCategoriesTable') ? document.getElementById('expenseCategoriesTable').querySelector('tbody') : null;
    if (categoriesTableBody) {
        categoriesTableBody.innerHTML = '';
    }
    
    // Load expense categories
    const savedCategories = localStorage.getItem('expenseCategories');
    if (savedCategories) {
        const categories = JSON.parse(savedCategories);
        categories.forEach(category => {
            addExpenseCategoryToTable(category.name, category.description);
        });
    }
    
    // Update expense category dropdown
    updateExpenseCategoryDropdown();
    
    // Clear complaints tables before loading
    const residentComplaintsTableBody = document.querySelector('#resident-dashboard .complaints-form').nextElementSibling.querySelector('tbody');
    if (residentComplaintsTableBody) {
        residentComplaintsTableBody.innerHTML = '';
    }
    
    const presidentComplaintsTableBody = document.querySelector('#president-dashboard .complaints-table tbody');
    if (presidentComplaintsTableBody) {
        presidentComplaintsTableBody.innerHTML = '';
    }
    
    // Load complaints
    const savedComplaints = localStorage.getItem('complaints');
    if (savedComplaints) {
        const complaints = JSON.parse(savedComplaints);
        complaints.forEach(complaint => {
            // Add to resident complaints table
            const residentTbody = document.querySelector('#resident-dashboard .complaints-form').nextElementSibling.querySelector('tbody');
            if (residentTbody) {
                const newRow = document.createElement('tr');
                newRow.innerHTML = `
                    <td>${complaint.id}</td>
                    <td>${complaint.category}</td>
                    <td>${complaint.subject}</td>
                    <td><span class="status ${complaint.status.toLowerCase().replace(' ', '-')}">${complaint.status}</span></td>
                    <td>${new Date(complaint.date).toLocaleDateString()}</td>
                    <td class="president-note">-</td>
                `;
                residentTbody.appendChild(newRow);
            }
            
            // Add to president dashboard complaint table
            const presidentTbody = document.querySelector('#president-dashboard .complaints-table tbody');
            if (presidentTbody) {
                const newRow = document.createElement('tr');
                newRow.innerHTML = `
                    <td>${complaint.id}</td>
                    <td>${complaint.flat || 'A-102'}</td>
                    <td>${complaint.category}</td>
                    <td>${complaint.description || complaint.subject}</td>
                    <td>
                        <select class="status-select">
                            <option value="Open" ${complaint.status === 'Open' ? 'selected' : ''}>Open</option>
                            <option value="In Progress" ${complaint.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
                            <option value="Resolved" ${complaint.status === 'Resolved' ? 'selected' : ''}>Resolved</option>
                        </select>
                    </td>
                    <td>
                        <input type="text" class="note-input" placeholder="Add note" data-complaint-id="${complaint.id}">
                        <button class="btn btn-small btn-primary save-note" data-complaint-id="${complaint.id}">Save</button>
                    </td>
                `;
                presidentTbody.appendChild(newRow);
                
                // Add event listener to the new select element
                const newSelect = newRow.querySelector('.status-select');
                newSelect.addEventListener('change', function() {
                    updateComplaintStatus(complaint.id, this.value);
                    updateResidentComplaintStatus(complaint.id, this.value);
                });
                
                // Add event listener to the new save note button
                const saveNoteBtn = newRow.querySelector('.save-note');
                saveNoteBtn.addEventListener('click', function() {
                    const noteInput = newRow.querySelector('.note-input');
                    const noteText = noteInput.value.trim();
                    
                    if (noteText) {
                        saveComplaintNote(complaint.id, noteText);
                        alert(`Note saved for complaint ${complaint.id}`);
                    }
                });
            }
        });
    }
    
    // Display service requests if president dashboard is visible
    if (document.getElementById('president-dashboard').style.display !== 'none') {
        setTimeout(displayServiceRequests, 100);
    }
    
    // Load complaint notes
    loadComplaintNotes();
    
    // Load past meetings
    loadPastMeetings();
}

// Save expense category to localStorage
function saveExpenseCategory(name, description) {
    const savedCategories = localStorage.getItem('expenseCategories');
    let categories = savedCategories ? JSON.parse(savedCategories) : [];
    
    // Check if category already exists
    const existingIndex = categories.findIndex(cat => cat.name === name);
    if (existingIndex !== -1) {
        // Update existing category
        categories[existingIndex] = {
            name: name,
            description: description
        };
    } else {
        // Add new category
        categories.push({
            name: name,
            description: description
        });
    }
    
    localStorage.setItem('expenseCategories', JSON.stringify(categories));
}

// Save expense to localStorage
function saveExpense(date, category, amount, notes) {
    const savedExpenses = localStorage.getItem('expenses');
    let expenses = savedExpenses ? JSON.parse(savedExpenses) : [];
    expenses.push({
        date: date,
        category: category,
        amount: amount,
        notes: notes
    });
    localStorage.setItem('expenses', JSON.stringify(expenses));
}

// Save meeting to localStorage
function saveMeeting(date, time, agenda) {
    const savedMeetings = localStorage.getItem('meetings');
    let meetings = savedMeetings ? JSON.parse(savedMeetings) : [];
    meetings.push({
        date: date,
        time: time,
        agenda: agenda
    });
    localStorage.setItem('meetings', JSON.stringify(meetings));
}

// Save past meeting to localStorage
function savePastMeeting(date, agenda, minutes, documentName, documentData) {
    const savedPastMeetings = localStorage.getItem('pastMeetings');
    let pastMeetings = savedPastMeetings ? JSON.parse(savedPastMeetings) : [];
    
    const newMeeting = {
        id: 'pm-' + Date.now(), // Generate unique ID
        date: date,
        agenda: agenda,
        minutes: minutes || '',
        documentName: documentName || null,
        documentData: documentData || null,
        createdAt: new Date().toISOString()
    };
    
    pastMeetings.push(newMeeting);
    localStorage.setItem('pastMeetings', JSON.stringify(pastMeetings));
}

// Save resident to localStorage
function saveResident(flatNumber, name, email, phone, services = []) {
    const savedResidents = localStorage.getItem('residents');
    let residents = savedResidents ? JSON.parse(savedResidents) : [];
    
    // Get all services with their types
    const savedServices = localStorage.getItem('services');
    const allServices = savedServices ? JSON.parse(savedServices) : [];
    
    // Add compulsory services to the resident's services
    const residentServices = [...services];
    allServices.forEach(service => {
        if (service.type === 'compulsory' && !residentServices.includes(service.name)) {
            residentServices.push(service.name);
        }
    });
    
    residents.push({
        flatNumber: flatNumber,
        name: name,
        email: email,
        phone: phone,
        services: residentServices
    });
    localStorage.setItem('residents', JSON.stringify(residents));
    
    // Refresh the Residents & Balances table in President Portal
    const authData = localStorage.getItem(AUTH_KEY);
    if (authData) {
        const userData = JSON.parse(authData);
        if (userData.role === 'president') {
            setTimeout(populateResidentsBalancesTable, 100);
        }
    }
}

// Update resident in localStorage
function updateResident(id, flatNumber, name, email, phone, services = []) {
    const savedResidents = localStorage.getItem('residents');
    if (savedResidents) {
        let residents = JSON.parse(savedResidents);
        // Find and update the specific resident
        const index = residents.findIndex(resident => resident.flatNumber === id);
        if (index !== -1) {
            // Get all services with their types
            const savedServices = localStorage.getItem('services');
            const allServices = savedServices ? JSON.parse(savedServices) : [];
            
            // Add compulsory services to the resident's services
            const residentServices = [...services];
            allServices.forEach(service => {
                if (service.type === 'compulsory' && !residentServices.includes(service.name)) {
                    residentServices.push(service.name);
                }
            });
            
            residents[index] = {
                flatNumber: flatNumber,
                name: name,
                email: email,
                phone: phone,
                services: residentServices
            };
            localStorage.setItem('residents', JSON.stringify(residents));
            
            // Refresh the Residents & Balances table in President Portal
            const authData = localStorage.getItem(AUTH_KEY);
            if (authData) {
                const userData = JSON.parse(authData);
                if (userData.role === 'president') {
                    setTimeout(populateResidentsBalancesTable, 100);
                }
            }
        }
    }
}

// Save service to localStorage
function saveService(name, description, charge, frequency, serviceType = 'optional') {
    const savedServices = localStorage.getItem('services');
    let services = savedServices ? JSON.parse(savedServices) : [];
    services.push({
        id: 'svc-' + Date.now(), // Generate unique ID
        name: name,
        description: description,
        charge: charge,
        frequency: frequency,
        type: serviceType
    });
    localStorage.setItem('services', JSON.stringify(services));
    
    // Refresh the Residents & Balances table in President Portal
    const authData = localStorage.getItem(AUTH_KEY);
    if (authData) {
        const userData = JSON.parse(authData);
        if (userData.role === 'president') {
            setTimeout(populateResidentsBalancesTable, 100);
        }
    }
}

// Update service in localStorage
function updateService(id, name, description, charge, frequency, serviceType = 'optional') {
    const savedServices = localStorage.getItem('services');
    if (savedServices) {
        let services = JSON.parse(savedServices);
        // Find and update the specific service
        const index = services.findIndex(service => service.id === id);
        if (index !== -1) {
            services[index] = {
                id: id,
                name: name,
                description: description,
                charge: charge,
                frequency: frequency,
                type: serviceType
            };
            localStorage.setItem('services', JSON.stringify(services));
            
            // Refresh the Residents & Balances table in President Portal
            const authData = localStorage.getItem(AUTH_KEY);
            if (authData) {
                const userData = JSON.parse(authData);
                if (userData.role === 'president') {
                    setTimeout(populateResidentsBalancesTable, 100);
                }
            }
        }
    }
}// Table Data Management Functions
// Add expense category to table
function addExpenseCategoryToTable(name, description) {
    const tbody = document.getElementById('expenseCategoriesTable') ? document.getElementById('expenseCategoriesTable').querySelector('tbody') : null;
    if (tbody) {
        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>${name}</td>
            <td>${description || ''}</td>
            <td>
                <button class="btn btn-small btn-secondary edit-category">Edit</button>
                <button class="btn btn-small btn-danger delete-category">Delete</button>
            </td>
        `;
        tbody.appendChild(newRow);
        
        // Add event listeners for edit and delete buttons
        const editBtn = newRow.querySelector('.edit-category');
        const deleteBtn = newRow.querySelector('.delete-category');
        
        if (editBtn) {
            editBtn.addEventListener('click', function() {
                editExpenseCategory(newRow, name, description);
            });
        }
        
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function() {
                if (confirm('Are you sure you want to delete this category?')) {
                    newRow.remove();
                    removeExpenseCategoryFromStorage(name);
                    updateExpenseCategoryDropdown();
                }
            });
        }
    }
}

// Edit expense category
function editExpenseCategory(row, name, description) {
    const categoryNameInput = document.getElementById('expenseCategoryName');
    const categoryDescriptionInput = document.getElementById('expenseCategoryDescription');
    
    if (categoryNameInput && categoryDescriptionInput) {
        categoryNameInput.value = name;
        categoryDescriptionInput.value = description || '';
        
        // Scroll to the form
        categoryNameInput.scrollIntoView({ behavior: 'smooth' });
    }
}

// Remove expense category from localStorage
function removeExpenseCategoryFromStorage(name) {
    const savedCategories = localStorage.getItem('expenseCategories');
    if (savedCategories) {
        let categories = JSON.parse(savedCategories);
        categories = categories.filter(cat => cat.name !== name);
        localStorage.setItem('expenseCategories', JSON.stringify(categories));
    }
}

// Add expense to table
function addExpenseToTable(date, category, amount, notes) {
    const tbody = document.querySelector('#president-dashboard .expenses-form').nextElementSibling.querySelector('tbody');
    if (tbody) {
        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>${date}</td>
            <td>${category}</td>
            <td>$${parseFloat(amount).toFixed(2)}</td>
            <td>${notes}</td>
        `;
        tbody.insertBefore(newRow, tbody.firstChild);
    }
}

// Add collection to table (treasurer dashboard)
function addCollectionToTable(date, flatNumber, amount, mode, remarks) {
    const tbody = document.querySelector('#treasurer-dashboard .collections-form').nextElementSibling.querySelector('tbody');
    if (tbody) {
        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>${date}</td>
            <td>${flatNumber}</td>
            <td>$${parseFloat(amount).toFixed(2)}</td>
            <td>${mode}</td>
            <td>${remarks}</td>
        `;
        tbody.insertBefore(newRow, tbody.firstChild);
    }
}

// Save collection to localStorage
function saveCollection(date, flatNumber, amount, mode, remarks) {
    const savedCollections = localStorage.getItem('collections');
    let collections = savedCollections ? JSON.parse(savedCollections) : [];
    collections.push({
        date: date,
        flatNumber: flatNumber,
        amount: amount,
        mode: mode,
        remarks: remarks
    });
    localStorage.setItem('collections', JSON.stringify(collections));
    
    // Update billing records to mark payment
    updateBillingRecordForPayment(flatNumber, amount, date);
    
    // Update financial accounts based on payment mode
    updateFinancialAccounts(amount, mode, 'credit', `Collection from ${flatNumber}: ${remarks}`);
}

// Initialize financial accounts for a new society
function initializeFinancialAccounts() {
    const financialAccounts = localStorage.getItem('financialAccounts');
    if (!financialAccounts) {
        // Initialize with zero balances
        const accounts = {
            cashInHand: 0,
            bankBalance: 0,
            transactions: []
        };
        localStorage.setItem('financialAccounts', JSON.stringify(accounts));
    }
}

// Update financial accounts based on transaction type and mode
function updateFinancialAccounts(amount, mode, type, reason) {
    const financialAccounts = localStorage.getItem('financialAccounts');
    let accounts = financialAccounts ? JSON.parse(financialAccounts) : {
        cashInHand: 0,
        bankBalance: 0,
        transactions: []
    };
    
    const transactionAmount = parseFloat(amount) || 0;
    
    if (type === 'credit') {
        // Add money to account based on payment mode
        if (mode === 'Cash') {
            accounts.cashInHand += transactionAmount;
        } else {
            // All other modes (UPI, Bank Transfer, Cheque) go to bank
            accounts.bankBalance += transactionAmount;
        }
    } else if (type === 'debit') {
        // Subtract money from account
        if (mode === 'Cash') {
            accounts.cashInHand -= transactionAmount;
        } else {
            // All other modes go to bank
            accounts.bankBalance -= transactionAmount;
        }
    }
    
    // Record the transaction
    const transaction = {
        id: 'txn-' + Date.now(),
        date: new Date().toISOString().split('T')[0],
        amount: transactionAmount,
        mode: mode,
        type: type,
        reason: reason,
        cashBalance: accounts.cashInHand,
        bankBalance: accounts.bankBalance
    };
    
    accounts.transactions.push(transaction);
    
    // Save updated accounts
    localStorage.setItem('financialAccounts', JSON.stringify(accounts));
    
    // Update the UI displays
    updateFinancialDisplays();
}

// Update financial displays in the UI
function updateFinancialDisplays() {
    const financialAccounts = localStorage.getItem('financialAccounts');
    if (!financialAccounts) return;
    
    const accounts = JSON.parse(financialAccounts);
    
    // Update president dashboard
    const presidentCards = document.querySelectorAll('#president-dashboard .overview-cards .card');
    if (presidentCards.length >= 5) {
        // Cash in Hand is the 3rd card (index 2)
        const cashInHandElement = presidentCards[2].querySelector('p.amount');
        if (cashInHandElement) {
            cashInHandElement.textContent = `₹${accounts.cashInHand.toFixed(2)}`;
        }
        
        // Bank Balance is the 4th card (index 3)
        const bankBalanceElement = presidentCards[3].querySelector('p.amount');
        if (bankBalanceElement) {
            bankBalanceElement.textContent = `₹${accounts.bankBalance.toFixed(2)}`;
        }
    }
    
    // Update treasurer dashboard
    const treasurerCards = document.querySelectorAll('#treasurer-dashboard .overview-cards .card');
    if (treasurerCards.length >= 5) {
        // Cash in Hand is the 3rd card (index 2)
        const cashInHandElement = treasurerCards[2].querySelector('p.amount');
        if (cashInHandElement) {
            cashInHandElement.textContent = `₹${accounts.cashInHand.toFixed(2)}`;
        }
        
        // Bank Balance is the 4th card (index 3)
        const bankBalanceElement = treasurerCards[3].querySelector('p.amount');
        if (bankBalanceElement) {
            bankBalanceElement.textContent = `₹${accounts.bankBalance.toFixed(2)}`;
        }
    }
}

// Update resident's last payment date
function updateResidentLastPayment(flatNumber, paymentDate) {
    const savedResidents = localStorage.getItem('residents');
    if (savedResidents) {
        let residents = JSON.parse(savedResidents);
        const index = residents.findIndex(resident => resident.flatNumber === flatNumber);
        if (index !== -1) {
            // Add or update lastPaymentDate property
            residents[index].lastPaymentDate = paymentDate;
            localStorage.setItem('residents', JSON.stringify(residents));
        }
    }
}

// Add bank transaction to table
function addBankTransactionToTable(date, type, amount, mode, reason) {
    const tbody = document.querySelector('#treasurer-dashboard #bankTransactionsTable tbody');
    if (tbody) {
        const newRow = document.createElement('tr');
        
        // Get current balances
        const financialAccounts = localStorage.getItem('financialAccounts');
        const accounts = financialAccounts ? JSON.parse(financialAccounts) : { cashInHand: 0, bankBalance: 0 };
        
        const totalBalance = accounts.cashInHand + accounts.bankBalance;
        
        newRow.innerHTML = `
            <td>${date}</td>
            <td><span class="status ${type}">${type.charAt(0).toUpperCase() + type.slice(1)}</span></td>
            <td>₹${parseFloat(amount).toFixed(2)}</td>
            <td>${mode}</td>
            <td>${reason}</td>
            <td>₹${totalBalance.toFixed(2)}</td>
        `;
        tbody.insertBefore(newRow, tbody.firstChild);
    }
}

// Add meeting to table (both president and resident dashboards)
function addMeetingToTable(date, time, agenda) {
    // Add to president dashboard
    const presidentTbody = document.querySelector('#president-dashboard .meetings-form').nextElementSibling.querySelector('tbody');
    if (presidentTbody) {
        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>${date}</td>
            <td>${time}</td>
            <td>${agenda}</td>
            <td><span class="status upcoming">Upcoming</span></td>
        `;
        presidentTbody.insertBefore(newRow, presidentTbody.firstChild);
    }
    
    // Add to resident dashboard - Use more reliable selector
    // Find the "Upcoming Meetings" section in resident dashboard
    const residentDashboard = document.getElementById('resident-dashboard');
    if (residentDashboard) {
        // Look for the section with "Upcoming Meetings" heading
        const sections = residentDashboard.querySelectorAll('.section');
        let meetingsSection = null;
        
        for (let i = 0; i < sections.length; i++) {
            const heading = sections[i].querySelector('h3');
            if (heading && heading.textContent.trim() === 'Upcoming Meetings') {
                meetingsSection = sections[i];
                break;
            }
        }
        
        if (meetingsSection) {
            const table = meetingsSection.querySelector('table.data-table');
            if (table) {
                const tbody = table.querySelector('tbody');
                if (tbody) {
                    const newRow = document.createElement('tr');
                    newRow.innerHTML = `
                        <td>${date}</td>
                        <td>${time}</td>
                        <td>${agenda}</td>
                    `;
                    tbody.appendChild(newRow);
                }
            }
        }
    }
}

// Add past meeting to tables
function addPastMeetingToTable(date, agenda, minutes, documentName) {
    // Add to president dashboard past meetings table
    const presidentPastMeetingsTable = document.getElementById('pastMeetingsTable');
    if (presidentPastMeetingsTable) {
        const tbody = presidentPastMeetingsTable.querySelector('tbody');
        if (tbody) {
            const newRow = document.createElement('tr');
            
            // Create document cell content
            let documentCell = 'No document';
            if (documentName) {
                documentCell = `<a href="#" class="document-link" onclick="viewDocument('${documentName}')">${documentName}</a>`;
            }
            
            newRow.innerHTML = `
                <td>${date}</td>
                <td>${agenda}</td>
                <td class="minutes-cell">${minutes || ''}</td>
                <td class="document-cell">${documentCell}</td>
                <td>
                    <button class="btn btn-small btn-view view-minutes" data-minutes="${minutes || ''}">View Minutes</button>
                </td>
            `;
            tbody.appendChild(newRow);
            
            // Add event listener for view minutes button
            const viewMinutesBtn = newRow.querySelector('.view-minutes');
            viewMinutesBtn.addEventListener('click', function() {
                const minutesText = this.getAttribute('data-minutes');
                if (minutesText) {
                    alert(minutesText);
                } else {
                    alert('No minutes available for this meeting.');
                }
            });
        }
    }
    
    // Add to resident dashboard past meetings table
    const residentPastMeetingsTable = document.getElementById('residentPastMeetingsTable');
    if (residentPastMeetingsTable) {
        const tbody = residentPastMeetingsTable.querySelector('tbody');
        if (tbody) {
            const newRow = document.createElement('tr');
            
            // Create document cell content
            let documentCell = 'No document';
            if (documentName) {
                documentCell = `<a href="#" class="document-link" onclick="viewDocument('${documentName}')">${documentName}</a>`;
            }
            
            newRow.innerHTML = `
                <td>${date}</td>
                <td>${agenda}</td>
                <td class="minutes-cell">${minutes || ''}</td>
                <td class="document-cell">${documentCell}</td>
            `;
            tbody.appendChild(newRow);
        }
    }
}

// Add resident to table
function addResidentToTable(flatNumber, residentName, residentEmail, residentPhone, services = []) {
    const tbody = document.getElementById('residentsTable') ? document.getElementById('residentsTable').querySelector('tbody') : null;
    if (tbody) {
        // Calculate sum of obtained services charges only
        let monthlyCharges = 0;
        
        // Get all services with their charges
        const savedServices = localStorage.getItem('services');
        const allServices = savedServices ? JSON.parse(savedServices) : [];
        
        // Add charges for each service the resident has
        services.forEach(serviceName => {
            const serviceObj = allServices.find(s => s.name === serviceName);
            if (serviceObj) {
                // Add the service charge
                const charge = parseFloat(serviceObj.charge) || 0;
                monthlyCharges += charge;
            }
        });
        
        // Format services with types for display
        let formattedServices = 'Standard Services';
        if (services.length > 0) {
            formattedServices = services.map(serviceName => {
                const serviceObj = allServices.find(s => s.name === serviceName);
                const serviceType = serviceObj ? serviceObj.type : 'optional';
                return `${serviceName} (${serviceType})`;
            }).join(', ');
        }
        
        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>${flatNumber}</td>
            <td>${residentName}</td>
            <td>${residentEmail}<br>${residentPhone}</td>
            <td>${formattedServices}</td>
            <td>$${monthlyCharges.toFixed(2)}</td>
            <td>
                <button class="btn btn-small btn-secondary edit-resident">Edit</button>
                <button class="btn btn-small btn-danger delete-resident">Delete</button>
            </td>
        `;
        tbody.appendChild(newRow);
        
        // Add event listener for the edit button
        const editButton = newRow.querySelector('.edit-resident');
        if (editButton) {
            editButton.addEventListener('click', function() {
                editResident(newRow, flatNumber, residentName, residentEmail, residentPhone, services);
            });
        }
        
        // Add event listener for the delete button
        const deleteButton = newRow.querySelector('.delete-resident');
        if (deleteButton) {
            deleteButton.addEventListener('click', function() {
                if (confirm('Are you sure you want to delete this resident?')) {
                    newRow.remove();
                    // Also remove from localStorage
                    removeResidentFromStorage(flatNumber);
                }
            });
        }
    }
}

// Edit resident function
function editResident(row, flatNumber, residentName, residentEmail, residentPhone, services = []) {
    // Populate the resident modal with existing data
    const residentModal = document.getElementById('residentModal');
    const residentModalTitle = document.getElementById('residentModalTitle');
    const residentForm = document.getElementById('residentForm');
    
    if (residentModal && residentForm) {
        // Set the modal title
        residentModalTitle.textContent = 'Edit Resident';
        
        // Populate form fields
        document.getElementById('residentId').value = flatNumber; // Using flatNumber as ID for simplicity
        document.getElementById('flatNumber').value = flatNumber;
        document.getElementById('residentName').value = residentName;
        document.getElementById('residentEmail').value = residentEmail;
        document.getElementById('residentPhone').value = residentPhone;
        
        // Populate services checkboxes
        populateServicesCheckboxes(services);
        
        // Show the modal
        residentModal.style.display = 'block';
    }
}

// Populate services checkboxes in the resident form
function populateServicesCheckboxes(selectedServices = []) {
    const servicesContainer = document.getElementById('servicesCheckboxes');
    if (servicesContainer) {
        // Clear existing checkboxes
        servicesContainer.innerHTML = '';
        
        // Get services from localStorage
        const savedServices = localStorage.getItem('services');
        let availableServices = [];
        
        if (savedServices) {
            availableServices = JSON.parse(savedServices);
        } else {
            // Sample services - fallback if no services exist
            availableServices = [
                {name: 'Parking Slot', type: 'optional'},
                {name: 'Water Connection', type: 'compulsory'},
                {name: 'Electricity Connection', type: 'compulsory'},
                {name: 'Gym Access', type: 'optional'},
                {name: 'Swimming Pool Access', type: 'optional'},
                {name: 'Security Service', type: 'compulsory'},
                {name: 'Housekeeping', type: 'optional'},
                {name: 'Internet/WiFi', type: 'optional'}
            ];
        }
        
        // Create checkboxes for each service
        availableServices.forEach(service => {
            // Handle both localStorage services (objects) and fallback services (objects)
            const serviceName = typeof service === 'string' ? service : service.name;
            const serviceType = service.type || 'optional';
            
            const checkboxDiv = document.createElement('div');
            checkboxDiv.className = 'checkbox-item';
            
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.id = `service_${serviceName.replace(/\s+/g, '_')}`;
            checkbox.name = 'residentServices';
            checkbox.value = serviceName;
            
            // Automatically check compulsory services
            if (serviceType === 'compulsory') {
                checkbox.checked = true;
                checkbox.disabled = true; // Compulsory services can't be unchecked
            } else {
                // Check if this service should be selected
                if (selectedServices.includes(serviceName)) {
                    checkbox.checked = true;
                }
            }
            
            const label = document.createElement('label');
            label.htmlFor = checkbox.id;
            // Handle cases where service type might be missing
            const displayServiceType = serviceType || 'optional';
            label.textContent = `${serviceName} (${displayServiceType})`;
            
            checkboxDiv.appendChild(checkbox);
            checkboxDiv.appendChild(label);
            servicesContainer.appendChild(checkboxDiv);
        });
    }
}

// Update resident in table
function updateResidentInTable(row, flatNumber, residentName, residentEmail, residentPhone, services = []) {
    if (row) {
        // Calculate sum of obtained services charges only
        let monthlyCharges = 0;
        
        // Get all services with their charges
        const savedServices = localStorage.getItem('services');
        const allServices = savedServices ? JSON.parse(savedServices) : [];
        
        // Add charges for each service the resident has
        services.forEach(serviceName => {
            const serviceObj = allServices.find(s => s.name === serviceName);
            if (serviceObj) {
                // Add the service charge
                const charge = parseFloat(serviceObj.charge) || 0;
                monthlyCharges += charge;
            }
        });
        
        // Format services with types for display
        let formattedServices = 'Standard Services';
        if (services.length > 0) {
            formattedServices = services.map(serviceName => {
                const serviceObj = allServices.find(s => s.name === serviceName);
                const serviceType = serviceObj ? serviceObj.type : 'optional';
                return `${serviceName} (${serviceType})`;
            }).join(', ');
        }
        
        // Update row content
        row.innerHTML = `
            <td>${flatNumber}</td>
            <td>${residentName}</td>
            <td>${residentEmail}<br>${residentPhone}</td>
            <td>${formattedServices}</td>
            <td>$${monthlyCharges.toFixed(2)}</td>
            <td>
                <button class="btn btn-small btn-secondary edit-resident">Edit</button>
                <button class="btn btn-small btn-danger delete-resident">Delete</button>
            </td>
        `;
        
        // Re-attach event listeners for the new buttons
        const editButton = row.querySelector('.edit-resident');
        if (editButton) {
            editButton.addEventListener('click', function() {
                editResident(row, flatNumber, residentName, residentEmail, residentPhone, services);
            });
        }
        
        const deleteButton = row.querySelector('.delete-resident');
        if (deleteButton) {
            deleteButton.addEventListener('click', function() {
                if (confirm('Are you sure you want to delete this resident?')) {
                    row.remove();
                    // Also remove from localStorage
                    removeResidentFromStorage(flatNumber);
                }
            });
        }
    }
}

// Add service to table
function addServiceToTable(serviceName, serviceDescription, serviceCharge, serviceFrequency, serviceType = 'optional', serviceId = null) {
    const tbody = document.getElementById('servicesTable') ? document.getElementById('servicesTable').querySelector('tbody') : null;
    if (tbody) {
        const newRow = document.createElement('tr');
        // Use provided serviceId or generate one based on timestamp
        const id = serviceId || 'svc-' + Date.now();
        newRow.setAttribute('data-service-id', id);
        
        newRow.innerHTML = `
            <td>${serviceName}</td>
            <td>${serviceDescription}</td>
            <td>$${parseFloat(serviceCharge).toFixed(2)}</td>
            <td>${serviceFrequency}</td>
            <td>${serviceType.charAt(0).toUpperCase() + serviceType.slice(1)}</td>
            <td>
                <button class="btn btn-small btn-secondary edit-service" data-service-id="${id}">Edit</button>
                <button class="btn btn-small btn-danger delete-service" data-service-id="${id}">Delete</button>
            </td>
        `;
        tbody.appendChild(newRow);
        
        // Event listeners are now handled via event delegation on the table
    }
}// Add service to charges setup section (deprecated)
function addServiceToChargesSetup(serviceName, serviceCharge) {
    // This function is deprecated as we've removed the separate charges setup section
    // All service charges are now managed through the Services & Charges Management section
    console.log(`Service ${serviceName} with charge $${serviceCharge} would be added to charges setup`);
}

// Update service in table
function updateServiceInTable(serviceId, serviceName, serviceDescription, serviceCharge, serviceFrequency, serviceType = 'optional') {
    const servicesTable = document.getElementById('servicesTable');
    if (servicesTable) {
        const rows = servicesTable.querySelectorAll('tbody tr');
        let targetRow = null;
        
        // Find the row with the matching service ID
        rows.forEach(row => {
            if (row.getAttribute('data-service-id') === serviceId) {
                targetRow = row;
            }
        });
        
        if (targetRow) {
            // Update the row content
            targetRow.innerHTML = `
                <td>${serviceName}</td>
                <td>${serviceDescription}</td>
                <td>$${parseFloat(serviceCharge).toFixed(2)}</td>
                <td>${serviceFrequency}</td>
                <td>${serviceType.charAt(0).toUpperCase() + serviceType.slice(1)}</td>
                <td>
                    <button class="btn btn-small btn-secondary edit-service" data-service-id="${serviceId}">Edit</button>
                    <button class="btn btn-small btn-danger delete-service" data-service-id="${serviceId}">Delete</button>
                </td>
            `;
            
            // Event listeners are now handled via event delegation on the table
        }
    }
}// Edit service function
function editService(serviceId, serviceName, serviceDescription, serviceCharge, serviceFrequency, serviceType = 'optional') {
    // Populate the service modal with existing data
    const serviceModal = document.getElementById('serviceModal');
    const serviceModalTitle = document.getElementById('serviceModalTitle');
    const serviceForm = document.getElementById('serviceForm');
    
    if (serviceModal && serviceForm) {
        // Set the modal title
        serviceModalTitle.textContent = 'Edit Service';
        
        // Populate form fields
        document.getElementById('serviceId').value = serviceId;
        document.getElementById('serviceName').value = serviceName;
        document.getElementById('serviceDescription').value = serviceDescription;
        document.getElementById('serviceCharge').value = serviceCharge;
        document.getElementById('serviceFrequency').value = serviceFrequency;
        document.getElementById('serviceType').value = serviceType;
        
        // Show the modal
        serviceModal.style.display = 'block';
    }
}// Remove service from localStorage
function removeServiceFromStorage(serviceId) {
    const savedServices = localStorage.getItem('services');
    if (savedServices) {
        let services = JSON.parse(savedServices);
        
        // Find the service being deleted to get its name
        const serviceToDelete = services.find(service => service.id === serviceId);
        const serviceName = serviceToDelete ? serviceToDelete.name : null;
        
        // Remove the service
        services = services.filter(service => service.id !== serviceId);
        localStorage.setItem('services', JSON.stringify(services));
        
        // If we have a service name, remove it from all residents who have it
        if (serviceName) {
            removeServiceFromAllResidents(serviceName);
        }
        
        // Refresh the Residents & Balances table in President Portal
        const authData = localStorage.getItem(AUTH_KEY);
        if (authData) {
            const userData = JSON.parse(authData);
            if (userData.role === 'president') {
                setTimeout(populateResidentsBalancesTable, 100);
            }
        }
    }
}

// Remove resident from localStorage
function removeResidentFromStorage(flatNumber) {
    const savedResidents = localStorage.getItem('residents');
    if (savedResidents) {
        let residents = JSON.parse(savedResidents);
        residents = residents.filter(resident => resident.flatNumber !== flatNumber);
        localStorage.setItem('residents', JSON.stringify(residents));
        
        // Refresh the Residents & Balances table in President Portal
        const authData = localStorage.getItem(AUTH_KEY);
        if (authData) {
            const userData = JSON.parse(authData);
            if (userData.role === 'president') {
                setTimeout(populateResidentsBalancesTable, 100);
            }
        }
    }
}

// Remove a service from all residents who have it assigned
function removeServiceFromAllResidents(serviceName) {
    const savedResidents = localStorage.getItem('residents');
    if (savedResidents) {
        let residents = JSON.parse(savedResidents);
        let updated = false;
        
        residents.forEach(resident => {
            if (resident.services && resident.services.includes(serviceName)) {
                resident.services = resident.services.filter(service => service !== serviceName);
                updated = true;
                
                // Update resident charges display
                updateResidentChargesDisplay(resident.flatNumber);
            }
        });
        
        if (updated) {
            localStorage.setItem('residents', JSON.stringify(residents));
            
            // Refresh residents table to show updated charges
            setTimeout(loadSavedData, 100);
            
            // Refresh resident dashboard if it's visible
            const residentDashboard = document.getElementById('resident-dashboard');
            if (residentDashboard && residentDashboard.style.display !== 'none') {
                setTimeout(displayResidentServices, 100);
            }
        }
    }
}

// Update resident charges display
function updateResidentChargesDisplay(flatNumber) {
    // This function ensures the resident's charges are recalculated and displayed correctly
    const residentDashboard = document.getElementById('resident-dashboard');
    if (residentDashboard && residentDashboard.style.display !== 'none') {
        // If we're on the resident dashboard and it belongs to this resident
        const authData = localStorage.getItem(AUTH_KEY);
        if (authData) {
            const userData = JSON.parse(authData);
            if (userData.role === 'resident' && userData.username === flatNumber) {
                setTimeout(displayResidentServices, 100);
            }
        }
    }
    
    // Update the residents table if president dashboard is visible
    const presidentDashboard = document.getElementById('president-dashboard');
    if (presidentDashboard && presidentDashboard.style.display !== 'none') {
        setTimeout(loadSavedData, 100);
    }
}

// Update complaint status in localStorage
function updateComplaintStatus(complaintId, newStatus) {
    const savedComplaints = localStorage.getItem('complaints');
    if (savedComplaints) {
        let complaints = JSON.parse(savedComplaints);
        const complaint = complaints.find(c => c.id === complaintId);
        if (complaint) {
            complaint.status = newStatus;
            localStorage.setItem('complaints', JSON.stringify(complaints));
            alert(`Complaint ${complaintId} status updated to ${newStatus}`);
        }
    }
}

// Update resident complaint status display
function updateResidentComplaintStatus(complaintId, newStatus) {
    // Update status in resident dashboard if visible
    const residentTbody = document.querySelector('#resident-dashboard .complaints-form').nextElementSibling.querySelector('tbody');
    if (residentTbody) {
        const rows = residentTbody.querySelectorAll('tr');
        rows.forEach(row => {
            const idCell = row.querySelector('td:first-child');
            if (idCell && idCell.textContent === complaintId) {
                const statusCell = row.querySelector('td:nth-child(4)');
                if (statusCell) {
                    statusCell.innerHTML = `<span class="status ${newStatus.toLowerCase().replace(' ', '-')}">${newStatus}</span>`;
                }
            }
        });
    }
}

// Save complaint note to localStorage
function saveComplaintNote(complaintId, noteText) {
    const savedNotes = localStorage.getItem('complaintNotes');
    let notes = savedNotes ? JSON.parse(savedNotes) : {};
    
    // Store note by complaint ID
    notes[complaintId] = noteText;
    
    localStorage.setItem('complaintNotes', JSON.stringify(notes));
    
    // Update the display in resident dashboard
    updateResidentComplaintNote(complaintId, noteText);
}

// Load complaint notes from localStorage
function loadComplaintNotes() {
    const savedNotes = localStorage.getItem('complaintNotes');
    if (savedNotes) {
        const notes = JSON.parse(savedNotes);
        
        // Populate note inputs in president dashboard
        Object.keys(notes).forEach(complaintId => {
            const noteInput = document.querySelector(`.note-input[data-complaint-id="${complaintId}"]`);
            if (noteInput) {
                noteInput.value = notes[complaintId];
            }
            
            // Update resident dashboard display
            updateResidentComplaintNote(complaintId, notes[complaintId]);
        });
    }
}

// Load past meetings from localStorage
function loadPastMeetings() {
    const savedPastMeetings = localStorage.getItem('pastMeetings');
    if (savedPastMeetings) {
        const pastMeetings = JSON.parse(savedPastMeetings);
        pastMeetings.forEach(meeting => {
            addPastMeetingToTable(meeting.date, meeting.agenda, meeting.minutes, meeting.documentName);
        });
    }
}

// View document function
function viewDocument(documentName) {
    alert(`In a real application, this would open the document: ${documentName}\n\nFor demonstration purposes, document viewing is simulated.`);
    return false; // Prevent default link behavior
}

// Update resident complaint note display
function updateResidentComplaintNote(complaintId, noteText) {
    // Update note in resident dashboard if visible
    const residentTbody = document.querySelector('#resident-dashboard .complaints-form').nextElementSibling.querySelector('tbody');
    if (residentTbody) {
        const rows = residentTbody.querySelectorAll('tr');
        rows.forEach(row => {
            const idCell = row.querySelector('td:first-child');
            if (idCell && idCell.textContent === complaintId) {
                const noteCell = row.querySelector('td.president-note');
                if (noteCell) {
                    noteCell.textContent = noteText || '-';
                }
            }
        });
    }
}

// Add resident complaint to table (both resident and president dashboards)
function addResidentComplaint(category, subject, description) {
    // Add to resident complaints table
    const residentTbody = document.querySelector('#resident-dashboard .complaints-form').nextElementSibling.querySelector('tbody');
    if (residentTbody) {
        const complaintId = 'CMP-' + (Date.now() % 100000).toString().padStart(3, '0');
        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>${complaintId}</td>
            <td>${category}</td>
            <td>${subject}</td>
            <td><span class="status open">Open</span></td>
            <td>${new Date().toLocaleDateString()}</td>
            <td class="president-note">-</td>
        `;
        residentTbody.appendChild(newRow);
        
        // Also add to president complaints table
        const presidentTbody = document.querySelector('#president-dashboard .complaints-table tbody');
        if (presidentTbody) {
            const presidentRow = document.createElement('tr');
            presidentRow.innerHTML = `
                <td>${complaintId}</td>
                <td>A-102</td>
                <td>${category}</td>
                <td>${description || subject}</td>
                <td>
                    <select class="status-select">
                        <option value="Open" selected>Open</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Resolved">Resolved</option>
                    </select>
                </td>
                <td>
                    <input type="text" class="note-input" placeholder="Add note" data-complaint-id="${complaintId}">
                    <button class="btn btn-small btn-primary save-note" data-complaint-id="${complaintId}">Save</button>
                </td>
            `;
            presidentTbody.appendChild(presidentRow);
            
            // Add event listener to the new select element
            const newSelect = presidentRow.querySelector('.status-select');
            newSelect.addEventListener('change', function() {
                updateComplaintStatus(complaintId, this.value);
                updateResidentComplaintStatus(complaintId, this.value);
            });
            
            // Add event listener to the new save note button
            const saveNoteBtn = presidentRow.querySelector('.save-note');
            saveNoteBtn.addEventListener('click', function() {
                const noteInput = presidentRow.querySelector('.note-input');
                const noteText = noteInput.value.trim();
                
                if (noteText) {
                    saveComplaintNote(complaintId, noteText);
                    alert(`Note saved for complaint ${complaintId}`);
                }
            });
        }
        
        return complaintId; // Return the complaint ID for further use
    }
    
    return null;
}

// Save resident complaint to localStorage
function saveResidentComplaint(category, subject, description) {
    const savedComplaints = localStorage.getItem('complaints');
    let complaints = savedComplaints ? JSON.parse(savedComplaints) : [];
    
    const complaintId = 'CMP-' + (Date.now() % 100000).toString().padStart(3, '0');
    complaints.push({
        id: complaintId,
        category: category,
        subject: subject,
        description: description,
        status: 'Open',
        date: new Date().toISOString(),
        flat: 'A-102' // Default flat for demo
    });
    
    localStorage.setItem('complaints', JSON.stringify(complaints));
}

// Add complaint to president dashboard table
function addComplaintToTable(complaintId, flat, category, description, status) {
    // Select the complaints table in the president dashboard
    let tbody = document.querySelector('#president-dashboard .section:nth-child(6) tbody'); // Complaints Overview table
    if (!tbody) {
        // Fallback selector
        const complaintsSection = document.querySelector('#president-dashboard .section h3');
        if (complaintsSection && complaintsSection.textContent.includes('Complaints')) {
            const table = complaintsSection.nextElementSibling;
            if (table && table.tagName === 'TABLE') {
                tbody = table.querySelector('tbody');
            }
        }
    }
    
    if (tbody) {
        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>${complaintId}</td>
            <td>${flat}</td>
            <td>${category}</td>
            <td>${description}</td>
            <td>
                <select class="status-select">
                    <option value="Open" ${status === 'Open' ? 'selected' : ''}>Open</option>
                    <option value="In Progress" ${status === 'In Progress' ? 'selected' : ''}>In Progress</option>
                    <option value="Resolved" ${status === 'Resolved' ? 'selected' : ''}>Resolved</option>
                </select>
            </td>
        `;
        tbody.appendChild(newRow);
        
        // Add event listener to the new select element
        const newSelect = newRow.querySelector('.status-select');
        newSelect.addEventListener('change', function() {
            updateComplaintStatus(complaintId, this.value);
        });
    }
}

// Permissions system
const permissions = {
    president: {
        canViewFinancialOverview: true,
        canConfigureCharges: true,
        canManageResidents: true,
        canManageRoles: true,
        canViewAllBalances: true,
        canCreateMeetings: true,
        canManageAnnouncements: true,
        canViewAllComplaints: true,
        canChangeComplaintStatus: true,
        canApproveExpenses: true,
        canAccessReports: true,
        canEditSocietySettings: true
    },
    treasurer: {
        canViewFinancialOverview: true,
        canConfigureCharges: false,
        canManageResidents: false,
        canManageRoles: false,
        canViewAllBalances: true,
        canCreateMeetings: false,
        canManageAnnouncements: false,
        canViewAllComplaints: true,
        canChangeComplaintStatus: false,
        canApproveExpenses: false,
        canAccessReports: true,
        canEditSocietySettings: false,
        canAddCollections: true,
        canAddExpenses: true
    },
    resident: {
        canViewFinancialOverview: false,
        canConfigureCharges: false,
        canManageResidents: false,
        canManageRoles: false,
        canViewAllBalances: false,
        canCreateMeetings: false,
        canManageAnnouncements: false,
        canViewAllComplaints: false,
        canChangeComplaintStatus: false,
        canApproveExpenses: false,
        canAccessReports: false,
        canEditSocietySettings: false,
        canViewOwnProfile: true,
        canViewOwnPayments: true,
        canViewOwnDues: true,
        canViewOwnServices: true,
        canCreateComplaints: true,
        canViewOwnComplaints: true,
        canViewMeetings: true
    }
};

// Check permissions and update UI accordingly
function checkPermissionsAndUI() {
    const authData = localStorage.getItem(AUTH_KEY);
    if (!authData) return;
    
    const userData = JSON.parse(authData);
    const role = userData.role;
    
    // Add role class to body for styling
    document.body.className = document.body.className.replace(/\brole-\w+\b/g, '') + ' role-' + role;
    
    // President Dashboard Permissions
    if (role === 'president') {
        // Add President Area label
        const dashboardHeader = document.querySelector('#president-dashboard .dashboard-header h2');
        if (dashboardHeader && !dashboardHeader.textContent.includes('President Area')) {
            dashboardHeader.innerHTML = 'President Area - ' + dashboardHeader.textContent;
        }
        
        // Show all sections for president
        const presidentSections = document.querySelectorAll('#president-dashboard .section');
        presidentSections.forEach(section => {
            section.style.opacity = '1';
            section.style.pointerEvents = 'auto';
        });
    }
    
    // Treasurer Dashboard Permissions
    if (role === 'treasurer') {
        // Add Treasurer Area label
        const dashboardHeader = document.querySelector('#treasurer-dashboard .dashboard-header h2');
        if (dashboardHeader && !dashboardHeader.textContent.includes('Treasurer Area')) {
            dashboardHeader.innerHTML = 'Treasurer Area - ' + dashboardHeader.textContent;
        }
        
        // Add restriction note
        const dashboardContent = document.querySelector('#treasurer-dashboard .dashboard-content');
        if (dashboardContent && !dashboardContent.querySelector('.restriction-note')) {
            const restrictionNote = document.createElement('div');
            restrictionNote.className = 'restriction-note';
            restrictionNote.innerHTML = '<p>🔒 Note: Configuration settings and resident management are only accessible to the President</p>';
            dashboardContent.insertBefore(restrictionNote, dashboardContent.firstChild);
        }
        
        // Hide president-only sections
        const configSections = document.querySelectorAll('#treasurer-dashboard .section.config-only');
        configSections.forEach(section => {
            section.style.display = 'none';
        });
    }
    
    // Resident Dashboard Permissions
    if (role === 'resident') {
        // Add Resident Portal label
        const dashboardHeader = document.querySelector('#resident-dashboard .dashboard-header h2');
        if (dashboardHeader && !dashboardHeader.textContent.includes('Resident Portal')) {
            dashboardHeader.innerHTML = 'Resident Portal - ' + dashboardHeader.textContent;
        }
        
        // Add restriction note
        const dashboardContent = document.querySelector('#resident-dashboard .dashboard-content');
        if (dashboardContent && !dashboardContent.querySelector('.restriction-note')) {
            const restrictionNote = document.createElement('div');
            restrictionNote.className = 'restriction-note';
            restrictionNote.innerHTML = '<p>🔒 Note: Administrative sections are only accessible to President and Treasurer</p>';
            dashboardContent.insertBefore(restrictionNote, dashboardContent.firstChild);
        }
        
        // Hide admin-only sections
        const adminSections = document.querySelectorAll('#resident-dashboard .section.admin-only');
        adminSections.forEach(section => {
            section.style.display = 'none';
        });
    }
}

// Populate Residents & Balances table in president dashboard
function populateResidentsBalancesTable() {
    const authData = localStorage.getItem(AUTH_KEY);
    if (!authData) return;
    
    const userData = JSON.parse(authData);
    if (userData.role !== 'president') return;
    
    const table = document.getElementById('residentsBalancesTable');
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    if (!tbody) return;
    
    // Clear existing data
    tbody.innerHTML = '';
    
    // Get residents from localStorage
    const savedResidents = localStorage.getItem('residents');
    const residents = savedResidents ? JSON.parse(savedResidents) : [];
    
    // Get collections from localStorage
    const savedCollections = localStorage.getItem('collections');
    const collections = savedCollections ? JSON.parse(savedCollections) : [];
    
    // Populate table with resident data
    residents.forEach(resident => {
        // Calculate monthly charges based on services
        let monthlyCharges = 0;
        
        // Get all services with their charges
        const savedServices = localStorage.getItem('services');
        const allServices = savedServices ? JSON.parse(savedServices) : [];
        
        // Add base maintenance charge
        monthlyCharges = 200; // Base maintenance from Maintenance service
        
        // Add charges for each service the resident has
        if (resident.services && Array.isArray(resident.services)) {
            resident.services.forEach(serviceName => {
                const serviceObj = allServices.find(s => s.name === serviceName);
                if (serviceObj) {
                    // Add the service charge
                    const charge = parseFloat(serviceObj.charge) || 0;
                    monthlyCharges += charge;
                }
            });
        }
        
        // If resident has maintenance service, subtract it since we already added base charge
        const hasMaintenance = resident.services && resident.services.includes('Maintenance');
        if (hasMaintenance) {
            // Find maintenance service charge and subtract it
            const maintenanceService = allServices.find(s => s.name === 'Maintenance');
            if (maintenanceService) {
                monthlyCharges -= parseFloat(maintenanceService.charge) || 0;
            }
        }
        
        // Find the most recent payment for this resident
        const residentCollections = collections.filter(c => c.flatNumber === resident.flatNumber);
        let paidAmount = 0;
        let lastPaidOn = '-';
        
        if (residentCollections.length > 0) {
            // Sort by date to get the most recent
            residentCollections.sort((a, b) => new Date(b.date) - new Date(a.date));
            const latestPayment = residentCollections[0];
            paidAmount = parseFloat(latestPayment.amount) || 0;
            lastPaidOn = latestPayment.date;
        }
        
        // Calculate due amount
        const dueAmount = monthlyCharges - paidAmount;
        
        // Determine status
        let statusClass = 'due';
        let statusText = 'Due';
        
        if (dueAmount <= 0) {
            statusClass = 'paid';
            statusText = 'Paid';
        } else if (paidAmount > 0) {
            statusClass = 'partial';
            statusText = 'Partial';
        }
        
        // Create table row
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${resident.flatNumber}</td>
            <td>${resident.name}</td>
            <td>$${monthlyCharges.toFixed(2)}</td>
            <td>$${paidAmount.toFixed(2)}</td>
            <td>${lastPaidOn}</td>
            <td>$${dueAmount.toFixed(2)}</td>
            <td><span class="status ${statusClass}">${statusText}</span></td>
        `;
        
        tbody.appendChild(row);
    });
}

// Display service requests in president dashboard
function displayServiceRequests() {
    const authData = localStorage.getItem(AUTH_KEY);
    if (!authData) return;
    
    const userData = JSON.parse(authData);
    if (userData.role !== 'president') return;
    
    const requestsTable = document.getElementById('serviceRequestsTable');
    if (!requestsTable) return;
    
    const tbody = requestsTable.querySelector('tbody');
    if (!tbody) return;
    
    const savedRequests = localStorage.getItem('serviceRequests');
    const requests = savedRequests ? JSON.parse(savedRequests) : [];
    
    // Filter for pending requests only
    const pendingRequests = requests.filter(request => request.status === 'pending');
    
    tbody.innerHTML = '';
    
    if (pendingRequests.length > 0) {
        // Get residents to check if services are already assigned
        const savedResidents = localStorage.getItem('residents');
        const residents = savedResidents ? JSON.parse(savedResidents) : [];
        
        pendingRequests.forEach(request => {
            // Check if service is already assigned to resident
            let isAssigned = false;
            const resident = residents.find(r => r.flatNumber === request.resident);
            if (resident && resident.services && resident.services.includes(request.serviceName)) {
                isAssigned = true;
            }
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${request.id}</td>
                <td>${request.serviceName}${isAssigned ? ' <span style="color: red;">(Already Assigned)</span>' : ''}</td>
                <td>${request.resident}</td>
                <td>${new Date(request.date).toLocaleDateString()}</td>
                <td><span class="status pending">Pending</span></td>
                <td>
                    <button class="btn btn-small btn-success approve-request" data-request-id="${request.id}" ${isAssigned ? 'disabled' : ''}>Approve</button>
                    <button class="btn btn-small btn-danger reject-request" data-request-id="${request.id}">Reject</button>
                </td>
            `;
            tbody.appendChild(row);
        });
        
        // Add event listeners for approve/reject buttons
        setTimeout(() => {
            const approveButtons = document.querySelectorAll('.approve-request');
            const rejectButtons = document.querySelectorAll('.reject-request');
            
            approveButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const requestId = this.getAttribute('data-request-id');
                    approveServiceRequest(requestId);
                });
            });
            
            rejectButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const requestId = this.getAttribute('data-request-id');
                    rejectServiceRequest(requestId);
                });
            });
        }, 100);
    } else {
        const row = document.createElement('tr');
        row.innerHTML = `<td colspan="6" style="text-align: center;">No pending service requests</td>`;
        tbody.appendChild(row);
    }
}

// Approve service request
function approveServiceRequest(requestId) {
    const savedRequests = localStorage.getItem('serviceRequests');
    let requests = savedRequests ? JSON.parse(savedRequests) : [];
    
    const requestIndex = requests.findIndex(req => req.id === requestId);
    if (requestIndex !== -1) {
        requests[requestIndex].status = 'approved';
        localStorage.setItem('serviceRequests', JSON.stringify(requests));
        
        // Add service to resident
        const serviceName = requests[requestIndex].serviceName;
        const residentId = requests[requestIndex].resident;
        
        // Get residents
        const savedResidents = localStorage.getItem('residents');
        let residents = savedResidents ? JSON.parse(savedResidents) : [];
        
        const residentIndex = residents.findIndex(res => res.flatNumber === residentId);
        if (residentIndex !== -1) {
            if (!residents[residentIndex].services) {
                residents[residentIndex].services = [];
            }
            
            // Check if service is already assigned
            if (!residents[residentIndex].services.includes(serviceName)) {
                residents[residentIndex].services.push(serviceName);
                localStorage.setItem('residents', JSON.stringify(residents));
                
                // Update resident charges display
                updateResidentChargesDisplay(residentId);
            } else {
                alert(`Service ${serviceName} is already assigned to resident ${residentId}.`);
                displayServiceRequests();
                return;
            }
        }
        
        alert(`Service request approved! ${serviceName} has been added to resident ${residentId}.`);
        displayServiceRequests();
        
        // Refresh resident dashboard if it's visible
        const residentDashboard = document.getElementById('resident-dashboard');
        if (residentDashboard && residentDashboard.style.display !== 'none') {
            setTimeout(displayResidentServices, 100);
        }
        
        // Refresh residents table to show updated charges
        setTimeout(loadSavedData, 100);
    }
}

// Reject service request
function rejectServiceRequest(requestId) {
    const savedRequests = localStorage.getItem('serviceRequests');
    let requests = savedRequests ? JSON.parse(savedRequests) : [];
    
    const requestIndex = requests.findIndex(req => req.id === requestId);
    if (requestIndex !== -1) {
        requests[requestIndex].status = 'rejected';
        localStorage.setItem('serviceRequests', JSON.stringify(requests));
        
        alert('Service request rejected.');
        displayServiceRequests();
        
        // Refresh resident dashboard if it's visible
        const residentDashboard = document.getElementById('resident-dashboard');
        if (residentDashboard && residentDashboard.style.display !== 'none') {
            setTimeout(displayResidentServices, 100);
        }
    }
}

// Display resident services
function displayResidentServices() {
    const authData = localStorage.getItem(AUTH_KEY);
    if (!authData) return;
    
    const userData = JSON.parse(authData);
    if (userData.role !== 'resident') return;
    
    // Get current resident services
    const savedResidents = localStorage.getItem('residents');
    if (!savedResidents) return;
    
    const residents = JSON.parse(savedResidents);
    // Find the resident by their username (which is their flat number)
    const resident = residents.find(r => r.flatNumber === userData.username);
    if (!resident) return;
    
    // Display obtained services
    const servicesList = document.getElementById('residentServicesList');
    if (servicesList) {
        servicesList.innerHTML = '';
        if (resident.services && Array.isArray(resident.services) && resident.services.length > 0) {
            // Get service types
            const savedServices = localStorage.getItem('services');
            const allServices = savedServices ? JSON.parse(savedServices) : [];
            
            resident.services.forEach(serviceName => {
                // Make sure serviceName is a string
                if (typeof serviceName !== 'string') return;
                
                const serviceObj = allServices.find(s => s.name === serviceName);
                // Handle cases where service type might be missing
                const serviceType = serviceObj ? (serviceObj.type || 'optional') : 'optional';
                
                const listItem = document.createElement('li');
                listItem.textContent = `${serviceName} (${serviceType})`;
                servicesList.appendChild(listItem);
            });
        } else {
            const listItem = document.createElement('li');
            listItem.textContent = 'No services assigned';
            servicesList.appendChild(listItem);
        }
    }
    
    // Display available services for request
    displayAvailableServicesForRequest(resident.services);
    
    // Update the dues section with calculated charges
    updateResidentDues(resident.services || []);
    
    // Display billing history
    displayBillingHistory(userData.username);
}

// Update resident dues display
function updateResidentDues(services = []) {
    // Make sure services is an array
    if (!Array.isArray(services)) {
        services = [];
    }
    
    // Calculate monthly charges based on services
    let monthlyCharges = 0;
    
    // Get all services with their charges
    const savedServices = localStorage.getItem('services');
    const allServices = savedServices ? JSON.parse(savedServices) : [];
    
    // Add base maintenance charge
    monthlyCharges = 200; // Base maintenance from Maintenance service
    
    // Add charges for each service the resident has
    services.forEach(serviceName => {
        // Make sure serviceName is a string
        if (typeof serviceName !== 'string') return;
        
        const serviceObj = allServices.find(s => s.name === serviceName);
        if (serviceObj) {
            // Add the service charge
            const charge = parseFloat(serviceObj.charge) || 0;
            monthlyCharges += charge;
        }
    });
    
    // If resident has maintenance service, subtract it since we already added base charge
    const hasMaintenance = services.includes('Maintenance');
    if (hasMaintenance) {
        // Find maintenance service charge and subtract it
        const maintenanceService = allServices.find(s => s.name === 'Maintenance');
        if (maintenanceService) {
            monthlyCharges -= parseFloat(maintenanceService.charge) || 0;
        }
    }
    
    // Get collections for this resident to calculate due amount
    const authData = localStorage.getItem(AUTH_KEY);
    if (authData) {
        const userData = JSON.parse(authData);
        if (userData.role === 'resident' && userData.username) {
            const savedCollections = localStorage.getItem('collections');
            const collections = savedCollections ? JSON.parse(savedCollections) : [];
            
            // Find collections for this resident
            const residentCollections = collections.filter(c => c.flatNumber === userData.username);
            let paidAmount = 0;
            
            if (residentCollections.length > 0) {
                // Sum all payments made by this resident
                residentCollections.forEach(collection => {
                    paidAmount += parseFloat(collection.amount) || 0;
                });
            }
            
            // Calculate actual due amount
            const dueAmount = Math.max(0, monthlyCharges - paidAmount);
            
            // Update the dues display in the resident dashboard
            const totalDueElement = document.querySelector('.dues-summary .due-item.total span');
            if (totalDueElement) {
                totalDueElement.textContent = `₹${dueAmount.toFixed(2)}`;
            }
        }
    }
}

// Display available services for request
function displayAvailableServicesForRequest(currentServices = []) {
    const servicesContainer = document.getElementById('availableServicesList');
    const requestBtn = document.getElementById('requestServiceBtn');
    
    if (!servicesContainer || !requestBtn) return;
    
    // Get all services
    const savedServices = localStorage.getItem('services');
    const allServices = savedServices ? JSON.parse(savedServices) : [];
    
    // Get current resident services if not provided
    let residentServices = currentServices;
    if (residentServices.length === 0) {
        const savedResidents = localStorage.getItem('residents');
        if (savedResidents) {
            const residents = JSON.parse(savedResidents);
            const resident = residents[0]; // For demo purposes, we'll use the first resident
            if (resident && resident.services) {
                residentServices = resident.services;
            }
        }
    }
    
    // Filter for optional services that are not already assigned
    const availableServices = allServices.filter(service => 
        service.type === 'optional' && 
        !residentServices.includes(service.name)
    );
    
    servicesContainer.innerHTML = '';
    
    if (availableServices.length > 0) {
        availableServices.forEach(service => {
            const serviceDiv = document.createElement('div');
            serviceDiv.className = 'checkbox-item';
            
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.id = `request_${service.name.replace(/\s+/g, '_')}`;
            checkbox.name = 'requestedServices';
            checkbox.value = service.name;
            
            const label = document.createElement('label');
            label.htmlFor = checkbox.id;
            // Handle cases where service properties might be missing
            const charge = service.charge || 0;
            const frequency = service.frequency || 'monthly';
            label.textContent = `${service.name} (₹${charge}/${frequency})`;
            
            serviceDiv.appendChild(checkbox);
            serviceDiv.appendChild(label);
            servicesContainer.appendChild(serviceDiv);
        });
        
        requestBtn.style.display = 'inline-block';
    } else {
        servicesContainer.innerHTML = '<p>No additional optional services available for request.</p>';
        requestBtn.style.display = 'none';
    }
}

// Handle service request submission
function handleServiceRequest() {
    const checkboxes = document.querySelectorAll('input[name="requestedServices"]:checked');
    const requestedServices = Array.from(checkboxes).map(cb => cb.value);
    
    if (requestedServices.length === 0) {
        alert('Please select at least one service to request.');
        return;
    }
    
    // Get current resident services to prevent requesting already assigned services
    const savedResidents = localStorage.getItem('residents');
    if (savedResidents) {
        const residents = JSON.parse(savedResidents);
        const resident = residents[0]; // For demo purposes, we'll use the first resident
        if (resident && resident.services) {
            // Filter out services that are already assigned to the resident
            const unassignedServices = requestedServices.filter(service => 
                !resident.services.includes(service)
            );
            
            if (unassignedServices.length === 0) {
                alert('All selected services are already assigned to you.');
                return;
            }
            
            if (unassignedServices.length < requestedServices.length) {
                alert(`Some services are already assigned to you. Requesting only the unassigned services.`);
            }
            
            // Update requestedServices to only include unassigned services
            requestedServices.splice(0, requestedServices.length, ...unassignedServices);
        }
    }
    
    // Prevent duplicate requests for the same service
    const savedRequests = localStorage.getItem('serviceRequests');
    let requests = savedRequests ? JSON.parse(savedRequests) : [];
    
    // Filter out services that already have pending requests
    const filteredServices = requestedServices.filter(serviceName => {
        return !requests.some(request => 
            request.serviceName === serviceName && 
            request.resident === 'A-102' && 
            request.status === 'pending'
        );
    });
    
    if (filteredServices.length === 0) {
        alert('All selected services already have pending requests.');
        return;
    }
    
    if (filteredServices.length < requestedServices.length) {
        alert(`Some services already have pending requests. Submitting requests only for services without pending requests.`);
    }
    
    // Update requestedServices to only include services without pending requests
    requestedServices.splice(0, requestedServices.length, ...filteredServices);
    
    // In a real app, this would be sent to the server for president approval
    // For demo purposes, we'll store in localStorage
    requests = savedRequests ? JSON.parse(savedRequests) : [];
    
    requestedServices.forEach(serviceName => {
        requests.push({
            id: 'req-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
            serviceName: serviceName,
            resident: 'A-102', // Demo resident
            status: 'pending',
            date: new Date().toISOString()
        });
    });
    
    localStorage.setItem('serviceRequests', JSON.stringify(requests));
    
    alert(`Service request(s) submitted successfully!\n\n${requestedServices.join('\n')}`);
    
    // Refresh the display
    displayResidentServices();
}

// Update expense category dropdown with saved categories
function updateExpenseCategoryDropdown() {
    const categorySelect = document.querySelector('#president-dashboard .expenses-form select');
    if (categorySelect) {
        // Save the current value
        const currentValue = categorySelect.value;
        
        // Clear existing options
        categorySelect.innerHTML = '';
        
        // Add a default "Select Category" option
        const defaultOption = document.createElement('option');
        defaultOption.value = '';
        defaultOption.textContent = 'Select Category';
        defaultOption.disabled = true;
        defaultOption.selected = true;
        categorySelect.appendChild(defaultOption);
        
        // Add saved categories (only the ones added by president)
        const savedCategories = localStorage.getItem('expenseCategories');
        if (savedCategories) {
            const categories = JSON.parse(savedCategories);
            categories.forEach(category => {
                const option = document.createElement('option');
                option.value = category.name;
                option.textContent = category.name;
                categorySelect.appendChild(option);
            });
        }
        
        // Restore the current value if it still exists
        if (currentValue) {
            categorySelect.value = currentValue;
        }
    }
}

// Initialize the app
checkAuthStatus();