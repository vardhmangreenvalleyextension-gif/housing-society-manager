// Role-based access control test functions

// Function to simulate login as different roles
function testRoleAccess(role) {
    // Clear any existing auth data
    localStorage.removeItem('mysociety_auth');
    
    // Simulate login with specified role
    const userData = {
        role: role,
        timestamp: new Date().toISOString()
    };
    
    localStorage.setItem('mysociety_auth', JSON.stringify(userData));
    
    // Reload the page to apply the role
    location.reload();
}

// Function to clear test data
function clearRoleTest() {
    localStorage.removeItem('mysociety_auth');
    location.reload();
}

// Function to check current role
function getCurrentRole() {
    const authData = localStorage.getItem('mysociety_auth');
    if (authData) {
        const userData = JSON.parse(authData);
        return userData.role;
    }
    return null;
}

// Function to verify permissions for current role
function verifyPermissions() {
    const role = getCurrentRole();
    if (!role) {
        console.log('No role found. Please log in first.');
        return;
    }
    
    // Permissions definitions (same as in app.js)
    const permissions = {
        president: {
            canViewFinancialOverview: true,
            canConfigureCharges: true,
            canManageResidents: true,
            canManageRoles: true,
            canViewAllBalances: true,
            canCreateMeetings: true,
            canManageAnnouncements: true,
            canViewAllComplaints: true,
            canChangeComplaintStatus: true,
            canApproveExpenses: true,
            canAccessReports: true,
            canEditSocietySettings: true
        },
        treasurer: {
            canViewFinancialOverview: true,
            canConfigureCharges: false,
            canManageResidents: false,
            canManageRoles: false,
            canViewAllBalances: true,
            canCreateMeetings: false,
            canManageAnnouncements: false,
            canViewAllComplaints: true,
            canChangeComplaintStatus: false,
            canApproveExpenses: false,
            canAccessReports: true,
            canEditSocietySettings: false,
            canAddCollections: true,
            canAddExpenses: true
        },
        resident: {
            canViewFinancialOverview: false,
            canConfigureCharges: false,
            canManageResidents: false,
            canManageRoles: false,
            canViewAllBalances: false,
            canCreateMeetings: false,
            canManageAnnouncements: false,
            canViewAllComplaints: false,
            canChangeComplaintStatus: false,
            canApproveExpenses: false,
            canAccessReports: false,
            canEditSocietySettings: false,
            canViewOwnProfile: true,
            canViewOwnPayments: true,
            canViewOwnDues: true,
            canViewOwnServices: true,
            canCreateComplaints: true,
            canViewOwnComplaints: true,
            canViewMeetings: true
        }
    };
    
    console.log(`Current role: ${role}`);
    console.log('Permissions:', permissions[role]);
    
    return {
        role: role,
        permissions: permissions[role]
    };
}

// Run verification when page loads
document.addEventListener('DOMContentLoaded', function() {
    const role = getCurrentRole();
    if (role) {
        console.log(`Currently logged in as: ${role}`);
        // Add a visual indicator to the page
        const indicator = document.createElement('div');
        indicator.style.position = 'fixed';
        indicator.style.top = '10px';
        indicator.style.right = '10px';
        indicator.style.backgroundColor = '#3498db';
        indicator.style.color = 'white';
        indicator.style.padding = '10px';
        indicator.style.borderRadius = '5px';
        indicator.style.zIndex = '9999';
        indicator.style.fontSize = '14px';
        indicator.innerHTML = `Role: <strong>${role.toUpperCase()}</strong> <button onclick="clearRoleTest()" style="margin-left: 10px; background: white; color: #3498db; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer;">Logout</button>`;
        document.body.appendChild(indicator);
    }
});