// Final API test
async function testAPI() {
    console.log('Testing MySociety Manager API...\n');
    
    try {
        // Test get all societies
        console.log('1. Testing GET /api/societies...');
        const societiesResponse = await fetch('http://localhost:3000/api/societies');
        const societiesData = await societiesResponse.json();
        console.log('Response:', societiesData);
        
        // Test register society
        console.log('\n2. Testing POST /api/societies/register...');
        const registerResponse = await fetch('http://localhost:3000/api/societies/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                societyName: 'API Test Society',
                address: '456 API Street',
                city: 'API City',
                numberOfFlats: 75,
                presidentName: 'API President',
                presidentEmail: 'api@test.com',
                presidentMobile: '9876543210',
                password: 'apitest123'
            }),
        });
        const registerData = await registerResponse.json();
        console.log('Response:', registerData);
        
        // Test search societies
        console.log('\n3. Testing GET /api/societies/search...');
        const searchResponse = await fetch('http://localhost:3000/api/societies/search?search=API&filter=all&page=1&limit=5');
        const searchData = await searchResponse.json();
        console.log('Response:', searchData);
        
        console.log('\nAPI testing completed successfully!');
    } catch (error) {
        console.error('API testing failed:', error);
    }
}

// Run the test
testAPI();