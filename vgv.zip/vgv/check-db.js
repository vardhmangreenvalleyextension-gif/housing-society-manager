const fs = require('fs');

// Read and display database content
fs.readFile('database.json', 'utf8', (err, data) => {
    if (err) {
        console.error('Error reading database:', err);
        return;
    }
    
    try {
        const db = JSON.parse(data);
        console.log('Database contents:');
        console.log(JSON.stringify(db, null, 2));
    } catch (parseErr) {
        console.error('Error parsing database:', parseErr);
    }
});