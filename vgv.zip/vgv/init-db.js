// Database initialization script
const fs = require('fs');
const path = require('path');

// Database file path
const dbFilePath = path.join(__dirname, 'database.json');

// Check if database file exists
if (!fs.existsSync(dbFilePath)) {
    console.log('Creating new database file...');
    
    // Initial database structure
    const initialData = {
        societies: [],
        residents: [],
        users: [],
        expenses: [],
        meetings: [],
        complaints: [],
        metadata: {
            lastSocietyId: 0,
            lastUserId: 0,
            lastResidentId: 0,
            createdAt: new Date().toISOString()
        }
    };
    
    // Write initial data to file
    fs.writeFileSync(dbFilePath, JSON.stringify(initialData, null, 2));
    console.log('Database initialized successfully!');
} else {
    console.log('Database file already exists.');
}

// Create a sample society for testing
const db = JSON.parse(fs.readFileSync(dbFilePath, 'utf8'));

// Add sample data if database is empty
if (db.societies.length === 0) {
    console.log('Adding sample data...');
    
    // Sample society
    db.metadata.lastSocietyId = 1;
    const sampleSociety = {
        id: 'SOC001',
        societyName: 'Green Valley Apartments',
        address: '123 Main Street',
        city: 'Mumbai',
        numberOfFlats: 50,
        presidentName: 'John Smith',
        presidentEmail: 'john@example.com',
        presidentMobile: '+91 98765 43210',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    db.societies.push(sampleSociety);
    
    // Sample users
    db.metadata.lastUserId = 3;
    const sampleUsers = [
        {
            id: 'USR001',
            name: 'John Smith',
            email: 'john@example.com',
            role: 'president',
            societyId: 'SOC001',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        },
        {
            id: 'USR002',
            name: 'Jane Treasurer',
            email: 'jane@example.com',
            role: 'treasurer',
            societyId: 'SOC001',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        },
        {
            id: 'USR003',
            name: 'Sarah Johnson',
            email: 'sarah@example.com',
            role: 'resident',
            societyId: 'SOC001',
            flat: 'A-102',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        }
    ];
    
    db.users = sampleUsers;
    
    // Sample residents
    db.metadata.lastResidentId = 5;
    const sampleResidents = [
        { id: 'RES001', societyId: 'SOC001', flat: 'A-101', name: 'John Smith', email: 'john@example.com', phone: '+91 98765 43210', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
        { id: 'RES002', societyId: 'SOC001', flat: 'A-102', name: 'Sarah Johnson', email: 'sarah@example.com', phone: '+91 98765 43211', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
        { id: 'RES003', societyId: 'SOC001', flat: 'A-103', name: 'Robert Davis', email: 'robert@example.com', phone: '+91 98765 43212', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
        { id: 'RES004', societyId: 'SOC001', flat: 'B-201', name: 'Emily Wilson', email: 'emily@example.com', phone: '+91 98765 43213', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
        { id: 'RES005', societyId: 'SOC001', flat: 'B-202', name: 'Michael Brown', email: 'michael@example.com', phone: '+91 98765 43214', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }
    ];
    
    db.residents = sampleResidents;
    
    // Write updated data to file
    fs.writeFileSync(dbFilePath, JSON.stringify(db, null, 2));
    console.log('Sample data added successfully!');
}

console.log('Database setup complete!');