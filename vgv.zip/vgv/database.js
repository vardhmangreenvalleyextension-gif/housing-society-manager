// Simple file-based database implementation
const fs = require('fs');
const path = require('path');

// Database file path
const dbFilePath = path.join(__dirname, 'database.json');

// Initialize database
function initDatabase() {
    if (!fs.existsSync(dbFilePath)) {
        const initialData = {
            societies: [],
            residents: [],
            users: [],
            expenses: [],
            meetings: [],
            complaints: [],
            metadata: {
                lastSocietyId: 0,
                lastUserId: 0,
                lastResidentId: 0,
                createdAt: new Date().toISOString()
            }
        };
        fs.writeFileSync(dbFilePath, JSON.stringify(initialData, null, 2));
    }
}

// Read database
function readDatabase() {
    try {
        const data = fs.readFileSync(dbFilePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading database:', error);
        return null;
    }
}

// Write database
function writeDatabase(data) {
    try {
        fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('Error writing to database:', error);
        return false;
    }
}

// Generate unique ID
function generateId(prefix, lastId) {
    return `${prefix}${String(lastId + 1).padStart(3, '0')}`;
}

// Society operations
function createSociety(societyData) {
    const db = readDatabase();
    if (!db) return null;
    
    // Increment society ID
    db.metadata.lastSocietyId += 1;
    const societyId = generateId('SOC', db.metadata.lastSocietyId);
    
    const newSociety = {
        id: societyId,
        ...societyData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    db.societies.push(newSociety);
    
    if (writeDatabase(db)) {
        return newSociety;
    }
    return null;
}

function getAllSocieties() {
    const db = readDatabase();
    return db ? db.societies : [];
}

function getSocietyById(id) {
    const db = readDatabase();
    if (!db) return null;
    
    return db.societies.find(society => society.id === id) || null;
}

function updateSociety(id, updateData) {
    const db = readDatabase();
    if (!db) return false;
    
    const societyIndex = db.societies.findIndex(society => society.id === id);
    if (societyIndex === -1) return false;
    
    db.societies[societyIndex] = {
        ...db.societies[societyIndex],
        ...updateData,
        updatedAt: new Date().toISOString()
    };
    
    return writeDatabase(db);
}

function deleteSociety(id) {
    const db = readDatabase();
    if (!db) return false;
    
    const societyIndex = db.societies.findIndex(society => society.id === id);
    if (societyIndex === -1) return false;
    
    db.societies.splice(societyIndex, 1);
    return writeDatabase(db);
}

// User operations
function createUser(userData) {
    const db = readDatabase();
    if (!db) return null;
    
    // Increment user ID
    db.metadata.lastUserId += 1;
    const userId = generateId('USR', db.metadata.lastUserId);
    
    const newUser = {
        id: userId,
        ...userData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    db.users.push(newUser);
    
    if (writeDatabase(db)) {
        return newUser;
    }
    return null;
}

function getUserByEmail(email) {
    const db = readDatabase();
    if (!db) return null;
    
    return db.users.find(user => user.email === email) || null;
}

function getAllUsers() {
    const db = readDatabase();
    return db ? db.users : [];
}

// Resident operations
function createResident(residentData) {
    const db = readDatabase();
    if (!db) return null;
    
    // Increment resident ID
    db.metadata.lastResidentId += 1;
    const residentId = generateId('RES', db.metadata.lastResidentId);
    
    const newResident = {
        id: residentId,
        ...residentData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    db.residents.push(newResident);
    
    if (writeDatabase(db)) {
        return newResident;
    }
    return null;
}

function getResidentById(id) {
    const db = readDatabase();
    if (!db) return null;
    
    return db.residents.find(resident => resident.id === id) || null;
}

function updateResident(id, updateData) {
    const db = readDatabase();
    if (!db) return false;
    
    const residentIndex = db.residents.findIndex(resident => resident.id === id);
    if (residentIndex === -1) return false;
    
    db.residents[residentIndex] = {
        ...db.residents[residentIndex],
        ...updateData,
        updatedAt: new Date().toISOString()
    };
    
    return writeDatabase(db);
}

function deleteResident(id) {
    const db = readDatabase();
    if (!db) return false;
    
    const residentIndex = db.residents.findIndex(resident => resident.id === id);
    if (residentIndex === -1) return false;
    
    db.residents.splice(residentIndex, 1);
    return writeDatabase(db);
}

function getResidentsBySocietyId(societyId) {
    const db = readDatabase();
    if (!db) return [];
    
    return db.residents.filter(resident => resident.societyId === societyId);
}

// Search and filter functions
function searchSocieties(query, filter) {
    const societies = getAllSocieties();
    
    return societies.filter(society => {
        const matchesQuery = !query || 
            society.societyName.toLowerCase().includes(query.toLowerCase()) ||
            society.address.toLowerCase().includes(query.toLowerCase()) ||
            society.city.toLowerCase().includes(query.toLowerCase()) ||
            society.presidentName.toLowerCase().includes(query.toLowerCase());
            
        const matchesFilter = filter === 'all' || !filter || society.city === filter;
        
        return matchesQuery && matchesFilter;
    });
}

// Initialize database on module load
initDatabase();

// Export functions
module.exports = {
    createSociety,
    getAllSocieties,
    getSocietyById,
    updateSociety,
    deleteSociety,
    createUser,
    getUserByEmail,
    getAllUsers,
    createResident,
    getResidentById,
    updateResident,
    deleteResident,
    getResidentsBySocietyId,
    searchSocieties
};