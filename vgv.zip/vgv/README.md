# MySociety Manager

A complete static website and front-end web app UI for a Housing Society Management Platform.

## Features

- Multi-page layout with responsive design
- Role-based dashboards for President, Treasurer, and Resident
- Interactive UI with form validations
- Data visualization using Chart.js
- Local storage simulation for authentication
- Full RESTful API for backend integration

## Pages

1. **Home/Landing Page**
   - Hero section with CTAs
   - Feature cards
   - Why choose us section
   - How it works explanation

2. **Authentication**
   - Login for different roles (President, Treasurer, Resident)
   - Society registration form

3. **Dashboards**
   - President Dashboard: Overview, residents & balances, service charges, expenses, meetings, complaints
   - Treasurer Dashboard: Collections, dues tracking, reports
   - Resident Dashboard: Profile, payment history, dues, services, complaints, meetings

4. **Other Pages**
   - Pricing plans
   - Contact form

## How to Run

### Method 1: Using the Built-in Server (Recommended)

1. Install Node.js if you haven't already
2. Navigate to the project directory and install dependencies:
   ```
   npm install
   ```
3. Start the server:
   ```
   npm start
   ```
   Or for development with auto-restart:
   ```
   npm run dev
   ```
4. Open your browser and go to `http://localhost:3000`

### Method 2: Direct Browser Opening
Simply open `index.html` in your browser. Note that API functionality will not work without a server.

## Technologies Used

- HTML5
- CSS3 (with Flexbox and Grid)
- JavaScript (ES6+)
- Chart.js for data visualization
- Node.js with Express for backend API
- RESTful API architecture

## Project Structure

```
├── index.html          # Main HTML file
├── styles.css          # Stylesheet
├── app.js              # JavaScript functionality
├── server/
│   └── index.js        # Express server with API endpoints
├── test_api.js         # API testing script
├── API_SETUP_GUIDE.md  # Detailed API documentation
└── README.md           # This file
```

## API Endpoints

The application includes a full RESTful API with the following endpoints:

- `POST /api/societies/register` - Register a new society
- `POST /api/auth/president/login` - President authentication
- `POST /api/auth/treasurer/login` - Treasurer authentication
- `POST /api/auth/resident/login` - Resident authentication
- `GET /api/societies/:id` - Get society details
- `GET /api/societies/:id/residents` - Get residents data

See `API_SETUP_GUIDE.md` for detailed API documentation and usage examples.

## Frontend Integration

The frontend JavaScript in `app.js` includes functions to call all API endpoints:

1. `registerSociety()` - Calls `/api/societies/register`
2. `loginPresident()` - Calls `/api/auth/president/login`
3. `loginTreasurer()` - Calls `/api/auth/treasurer/login`
4. `loginResident()` - Calls `/api/auth/resident/login`

These functions handle:
- Form data collection
- API requests with proper headers
- Response handling
- User feedback
- Loading states

## Customization

To customize the application:

1. Modify `index.html` to change the content and structure
2. Update `styles.css` to change the appearance
3. Edit `app.js` to modify functionality and add new features
4. Extend `server/index.js` to add new API endpoints

## Database Integration

In a production environment, you would integrate with a database:

1. Replace the in-memory data storage with database queries
2. Implement proper password hashing (bcrypt recommended)
3. Add JWT token generation and validation
4. Implement proper error handling and logging
5. Add data validation and sanitization

## Security Considerations

1. Always use HTTPS in production
2. Implement rate limiting to prevent abuse
3. Use environment variables for sensitive data
4. Implement proper authentication middleware
5. Sanitize all user inputs
6. Regularly update dependencies

## Testing

You can test the API using the provided test script:

```
node test_api.js
```

Or manually with tools like Postman or curl.