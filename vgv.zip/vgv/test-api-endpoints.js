// Test API endpoints
const http = require('http');

// Test getting all societies
const options = {
    hostname: 'localhost',
    port: 3000,
    path: '/api/societies',
    method: 'GET'
};

const req = http.request(options, (res) => {
    console.log(`Status Code: ${res.statusCode}`);
    
    res.on('data', (chunk) => {
        console.log(`Body: ${chunk}`);
    });
    
    res.on('end', () => {
        console.log('Request completed');
    });
});

req.on('error', (error) => {
    console.error('Error:', error);
});

req.end();