// Test database functions
const {
    createSociety,
    getAllSocieties,
    getSocietyById,
    updateSociety,
    deleteSociety,
    createUser,
    getUserByEmail,
    getAllUsers,
    createResident,
    getResidentsBySocietyId,
    searchSocieties
} = require('./database');

console.log('Testing database functions...');

// Test create society
console.log('\n1. Creating a test society...');
const newSociety = createSociety({
    societyName: 'Test Society',
    address: '123 Test Street',
    city: 'Test City',
    numberOfFlats: 100,
    presidentName: 'Test President',
    presidentEmail: 'test@example.com',
    presidentMobile: '1234567890'
});

console.log('Created society:', newSociety);

// Test get all societies
console.log('\n2. Getting all societies...');
const allSocieties = getAllSocieties();
console.log('All societies count:', allSocieties.length);

// Test search societies
console.log('\n3. Searching societies...');
const searchedSocieties = searchSocieties('Test', 'all');
console.log('Found societies:', searchedSocieties.length);

// Test create user
console.log('\n4. Creating a test user...');
const newUser = createUser({
    name: 'Test User',
    email: 'user@example.com',
    role: 'resident',
    societyId: newSociety.id
});

console.log('Created user:', newUser);

// Test get all users
console.log('\n5. Getting all users...');
const allUsers = getAllUsers();
console.log('All users count:', allUsers.length);

console.log('\nDatabase tests completed.');