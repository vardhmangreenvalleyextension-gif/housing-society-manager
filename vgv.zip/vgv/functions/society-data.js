// Netlify function for getting society data
exports.handler = async (event, context) => {
  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      body: JSON.stringify({ 
        success: false, 
        message: 'Method Not Allowed' 
      })
    };
  }
  
  try {
    const { id } = event.queryStringParameters || {};
    
    // Simulate fetching society data
    const society = {
      id: id || "123",
      name: "Green Valley Apartments",
      address: "123 Main Street",
      city: "Sample City",
      numberOfFlats: 50,
      president: {
        name: "John Smith",
        email: "john@example.com",
        phone: "+1234567890"
      }
    };
    
    return {
      statusCode: 200,
      body: JSON.stringify({ 
        success: true, 
        society: society 
      })
    };
  } catch (error) {
    console.error('Error fetching society:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        success: false, 
        message: 'Internal server error' 
      })
    };
  }
};