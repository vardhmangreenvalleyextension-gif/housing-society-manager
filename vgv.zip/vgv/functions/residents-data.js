// Netlify function for getting residents data
exports.handler = async (event, context) => {
  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      body: JSON.stringify({ 
        success: false, 
        message: 'Method Not Allowed' 
      })
    };
  }
  
  try {
    // Simulate fetching residents data
    const residents = [
      { flat: "A-101", name: "John Smith", totalCharges: 500, paid: 500, due: 0, status: "paid" },
      { flat: "A-102", name: "Sarah Johnson", totalCharges: 500, paid: 300, due: 200, status: "partial" },
      { flat: "A-103", name: "Robert Davis", totalCharges: 500, paid: 0, due: 500, status: "due" },
      { flat: "B-201", name: "Emily Wilson", totalCharges: 550, paid: 550, due: 0, status: "paid" },
      { flat: "B-202", name: "Michael Brown", totalCharges: 550, paid: 550, due: 0, status: "paid" }
    ];
    
    return {
      statusCode: 200,
      body: JSON.stringify({ 
        success: true, 
        residents: residents 
      })
    };
  } catch (error) {
    console.error('Error fetching residents:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        success: false, 
        message: 'Internal server error' 
      })
    };
  }
};