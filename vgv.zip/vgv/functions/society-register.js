// Netlify function for society registration
const { inspect } = require("util");
const path = require("path");

// Since we can't use fs in Netlify functions, we'll simulate database operations
// In a real implementation, this would connect to a database service

exports.handler = async (event, context) => {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ 
        success: false, 
        message: 'Method Not Allowed' 
      })
    };
  }
  
  try {
    const { societyName, address, city, numberOfFlats, presidentName, presidentEmail, presidentMobile, password } = JSON.parse(event.body);
    
    // Basic validation
    if (!societyName || !address || !city || !numberOfFlats || !presidentName || !presidentEmail || !presidentMobile || !password) {
      return {
        statusCode: 400,
        body: JSON.stringify({ 
          success: false, 
          message: 'All fields are required' 
        })
      };
    }
    
    // Simulate saving to database
    // In a real implementation, this would use the database.js functions
    const newSociety = {
      id: 'SOC' + Math.floor(Math.random() * 10000),
      societyName,
      address,
      city,
      numberOfFlats: parseInt(numberOfFlats),
      presidentName,
      presidentEmail,
      presidentMobile,
      createdAt: new Date().toISOString()
    };
    
    // Also create a user for the president
    const newUser = {
      id: 'USR' + Math.floor(Math.random() * 10000),
      name: presidentName,
      email: presidentEmail,
      role: 'president',
      societyId: newSociety.id,
      createdAt: new Date().toISOString()
    };
    
    return {
      statusCode: 201,
      body: JSON.stringify({ 
        success: true, 
        message: 'Society registered successfully!',
        society: newSociety,
        user: newUser
      })
    };
  } catch (error) {
    console.error('Registration error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        success: false, 
        message: 'Internal server error' 
      })
    };
  }
};