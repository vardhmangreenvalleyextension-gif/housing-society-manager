// Netlify function for getting all societies
exports.handler = async (event, context) => {
  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      body: JSON.stringify({ 
        success: false, 
        message: 'Method Not Allowed' 
      })
    };
  }
  
  try {
    // Simulate fetching all societies from database
    // In a real implementation, this would query the database
    const societies = [
      {
        id: 'SOC001',
        societyName: 'Green Valley Apartments',
        address: '123 Main Street',
        city: 'Mumbai',
        numberOfFlats: 50,
        presidentName: 'John Smith',
        presidentEmail: 'john@example.com',
        presidentMobile: '+91 98765 43210',
        createdAt: '2023-05-15T10:30:00Z'
      },
      {
        id: 'SOC002',
        societyName: 'Sunshine Residency',
        address: '456 Park Avenue',
        city: 'Delhi',
        numberOfFlats: 75,
        presidentName: 'Priya Sharma',
        presidentEmail: 'priya@example.com',
        presidentMobile: '+91 98765 43211',
        createdAt: '2023-05-18T14:45:00Z'
      },
      {
        id: 'SOC003',
        societyName: 'Lake View Colony',
        address: '789 Lake Road',
        city: 'Bangalore',
        numberOfFlats: 120,
        presidentName: 'Rajesh Kumar',
        presidentEmail: 'rajesh@example.com',
        presidentMobile: '+91 98765 43212',
        createdAt: '2023-05-20T09:15:00Z'
      },
      {
        id: 'SOC004',
        societyName: 'Skyline Towers',
        address: '101 Sky Street',
        city: 'Hyderabad',
        numberOfFlats: 90,
        presidentName: 'Anita Desai',
        presidentEmail: 'anita@example.com',
        presidentMobile: '+91 98765 43213',
        createdAt: '2023-05-22T16:20:00Z'
      },
      {
        id: 'SOC005',
        societyName: 'Garden Plaza',
        address: '202 Garden Lane',
        city: 'Chennai',
        numberOfFlats: 65,
        presidentName: 'Vikram Patel',
        presidentEmail: 'vikram@example.com',
        presidentMobile: '+91 98765 43214',
        createdAt: '2023-05-25T11:30:00Z'
      }
    ];
    
    return {
      statusCode: 200,
      body: JSON.stringify({ 
        success: true, 
        societies: societies,
        totalCount: societies.length
      })
    };
  } catch (error) {
    console.error('Error fetching societies:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        success: false, 
        message: 'Internal server error' 
      })
    };
  }
};