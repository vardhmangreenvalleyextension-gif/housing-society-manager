// Netlify function for president login
exports.handler = async (event, context) => {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ 
        success: false, 
        message: 'Method Not Allowed' 
      })
    };
  }
  
  try {
    const { email, password } = JSON.parse(event.body);
    
    // Basic validation
    if (!email || !password) {
      return {
        statusCode: 400,
        body: JSON.stringify({ 
          success: false, 
          message: 'Email and password are required' 
        })
      };
    }
    
    // Simulate authentication
    const user = {
      id: 1,
      name: "John Smith",
      email: email,
      role: "president"
    };
    
    return {
      statusCode: 200,
      body: JSON.stringify({ 
        success: true, 
        message: 'Login successful',
        user: user,
        token: "sample-jwt-token"
      })
    };
  } catch (error) {
    console.error('Login error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        success: false, 
        message: 'Internal server error' 
      })
    };
  }
};