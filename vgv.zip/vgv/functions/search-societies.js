// Netlify function for searching and filtering societies
exports.handler = async (event, context) => {
  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      body: JSON.stringify({ 
        success: false, 
        message: 'Method Not Allowed' 
      })
    };
  }
  
  try {
    // Get query parameters
    const { search, filter, page, limit } = event.queryStringParameters || {};
    
    // Simulate fetching societies from database with search and filter
    // In a real implementation, this would query the database
    let societies = [
      {
        id: 'SOC001',
        societyName: 'Green Valley Apartments',
        address: '123 Main Street',
        city: 'Mumbai',
        numberOfFlats: 50,
        presidentName: 'John Smith',
        presidentEmail: 'john@example.com',
        createdAt: '2023-05-15T10:30:00Z'
      },
      {
        id: 'SOC002',
        societyName: 'Sunshine Residency',
        address: '456 Park Avenue',
        city: 'Delhi',
        numberOfFlats: 75,
        presidentName: 'Priya Sharma',
        presidentEmail: 'priya@example.com',
        createdAt: '2023-05-18T14:45:00Z'
      },
      {
        id: 'SOC003',
        societyName: 'Lake View Colony',
        address: '789 Lake Road',
        city: 'Bangalore',
        numberOfFlats: 120,
        presidentName: 'Rajesh Kumar',
        presidentEmail: 'rajesh@example.com',
        createdAt: '2023-05-20T09:15:00Z'
      },
      {
        id: 'SOC004',
        societyName: 'Skyline Towers',
        address: '101 Sky Street',
        city: 'Hyderabad',
        numberOfFlats: 90,
        presidentName: 'Anita Desai',
        presidentEmail: 'anita@example.com',
        createdAt: '2023-05-22T16:20:00Z'
      },
      {
        id: 'SOC005',
        societyName: 'Garden Plaza',
        address: '202 Garden Lane',
        city: 'Chennai',
        numberOfFlats: 65,
        presidentName: 'Vikram Patel',
        presidentEmail: 'vikram@example.com',
        createdAt: '2023-05-25T11:30:00Z'
      },
      {
        id: 'SOC006',
        societyName: 'Mumbai Heights',
        address: '303 Hill Road',
        city: 'Mumbai',
        numberOfFlats: 80,
        presidentName: 'Sanjay Mehta',
        presidentEmail: 'sanjay@example.com',
        createdAt: '2023-05-28T13:45:00Z'
      },
      {
        id: 'SOC007',
        societyName: 'Delhi Gardens',
        address: '404 Green Park',
        city: 'Delhi',
        numberOfFlats: 110,
        presidentName: 'Anjali Gupta',
        presidentEmail: 'anjali@example.com',
        createdAt: '2023-05-30T15:20:00Z'
      }
    ];
    
    // Apply search filter
    if (search) {
      const searchTerm = search.toLowerCase();
      societies = societies.filter(society => 
        society.societyName.toLowerCase().includes(searchTerm) ||
        society.address.toLowerCase().includes(searchTerm) ||
        society.presidentName.toLowerCase().includes(searchTerm)
      );
    }
    
    // Apply city filter
    if (filter && filter !== 'all') {
      societies = societies.filter(society => society.city === filter);
    }
    
    // Apply pagination
    const pageNum = parseInt(page) || 1;
    const pageSize = parseInt(limit) || 5;
    const startIndex = (pageNum - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    const paginatedSocieties = societies.slice(startIndex, endIndex);
    
    return {
      statusCode: 200,
      body: JSON.stringify({ 
        success: true, 
        societies: paginatedSocieties,
        totalCount: societies.length,
        currentPage: pageNum,
        totalPages: Math.ceil(societies.length / pageSize)
      })
    };
  } catch (error) {
    console.error('Error searching societies:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        success: false, 
        message: 'Internal server error' 
      })
    };
  }
};